//var a = 10;
//var b = 20;
//var d = a - b;

//console.log(d);

//console.log("Hello everyone");
//console.log("Hi there!");

//Write a program to check whether the number is a positive number or not.

var n = -10;

if(n >= 0) {
   console.log("A");
   console.log("Number is positive");
} else {
   console.log("B");
   console.log("Number is negative");
}


//console.log(" ABC \n DEF");

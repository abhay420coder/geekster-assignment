1.  we’ll need a way to convert our ES6 code to portable ES5 code. 

    The tools discussed in this chapter are very common, 
    and you are likely to encounter them in any open source project or software development team. 
    
    They are:
        • Git, a version control tool that helps you manage your project as it grows, and
          collaborate with other developers.

        • Node, which allows you to run JavaScript outside of the browser (and comes with
          npm, which gives you access to the rest of the tools on this list).
        
        • Gulp, a build tool that automates common development tasks 
          (Grunt is a popular alternative).

        • Babel, a transcompiler that converts ES6 code to portable ES5 code.

        • ESLint, a linter that helps you avoid common mistakes and makes you a better
          programmer!
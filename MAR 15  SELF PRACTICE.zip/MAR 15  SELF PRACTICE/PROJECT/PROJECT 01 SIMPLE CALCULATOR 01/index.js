let screen = document.getElementById("screen");

// let btn = document.getElementsByTagName("button");
let btn = document.querySelectorAll("button");

for
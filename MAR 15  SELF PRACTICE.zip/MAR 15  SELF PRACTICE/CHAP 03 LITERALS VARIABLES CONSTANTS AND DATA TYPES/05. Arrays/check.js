

// const str = "Education"
// const arr = str.split("");
// console.log(arr);


// var arrNew = [];
// console.log(arrNew);


// for(let i = 0 ; i<arr.length ; i++)
// {
//     if ( (arr[i]!="a") && (arr[i]!="A") && (arr[i]!="e") && (arr[i]!="E") && (arr[i]!="i") && (arr[i]!="I") && (arr[i]!="o") && (arr[i]!="O") && (arr[i]!="u") && (arr[i]!="U") )
//     {
//         arrNew.push(arr[i]);
//     } 
// }
// console.log(arrNew);


// const strNew = arrNew.join("") 
// console.log( strNew );


















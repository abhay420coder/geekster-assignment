1. ARRAY :- 
            An array is a special variable, which can hold more than one value.

            The Array object, as with arrays in other programming languages, 
            enables storing a collection of multiple items under a single 
            variable name, and has members for performing common array operations.

            Arrays in JavaScript can be nonhomogeneous, 
            meaning the elements in an array do not need to be the
            same type (it follows from this that arrays can have 
            other arrays as elements, or objects). 
            
            Literal arrays are constructed with square brackets, and the same square
            brackets are used to access elements by index. 
            
            Every array has a length property, which tells you how many elements are in the array. 
            
            Assigning to an index that’s larger than the array will automatically make the array larger, 
            with unused indexes getting the value undefined. 
            
            You can also use the Array constructor to create arrays,
            though this is seldom necessary.

            EXAMPLE :- 
                    // array literals

                    const arr1 = [1, 2, 3]; // array of numbers

                    const arr2 = ["one", 2, "three"]; // nonhomogeneous array

                    const arr3 = [[1, 2, 3], ["one", 2, "three"]]; // array containing arrays

                    const arr4 = [ // nonhomogeneous array
                    { name: "Fred", type: "object", luckyNumbers = [5, 7, 13] },
                    [
                        { name: "Susan", type: "object" },
                        { name: "Anthony", type: "object" },
                    ],
                    1,
                    function() { return "arrays can contain functions too"; },
                    "three",
                    ];


                    // accessing elements
                    arr1[0]; // 1
                    arr1[2]; // 3
                    arr3[1]; // ["one", 2, "three"]
                    arr4[1][0]; // { name: "Susan", type: "object" }

                    // array length
                    arr1.length; // 3
                    arr4.length; // 5
                    arr4[1].length; // 2
                    
                    // increasing array size
                    arr1[4] = 5;
                    arr1; // [1, 2, 3, undefined, 5]
                    arr1.length; // 5

                    // accessing (not assigning) an index larger than the array
                    // does *not* change the size of the array
                    arr2[10]; // undefined
                    arr2.length; // 3

                    // Array constructor (rarely used)
                    const arr5 = new Array(); // empty array
                    const arr6 = new Array(1, 2, 3); // [1, 2, 3]
                    const arr7 = new Array(2); // array of length 2 (all elements undefined)
                    const arr8 = new Array("2"); // ["2"]





        

2. CREATE an array :- 

               Array() constructor    :- create Array objects.
                                    
                                    // literal constructor
                        SYNTAX :-   const array_name = [item1, item2, ...]; 

                        EXAMPLE :-  const arr1 = ["abhay" , 2 , {"key21" : "value21" , "key22":"value22"} , ["value30" , "value31" , "value33"]];
                                    console.log(arr1);  


                                    // construct from elements
                        SYNTAX :-   const array_name = new Array(element0, element1, /* ... ,*/ elementN)

                        EXAMPLE :-  const arr2 = new Array("abhay1" , 21 , {"key211" : "value211" , "key221":"value221"} , ["value301" , "value311" , "value331"]);
                                    console.log(arr2);
                                    

                                    // construct from array length
                        SYNTAX :-   const array_name = new Array(arrayLength)

                        EXAMPLE :-  const arr2 = new Array("abhay1" , 21 , {"key211" : "value211" , "key221":"value221"} , ["value301" , "value311" , "value331"]);
                                    console.log(arr2);  


                                    // construct from array length
                        SYNTAX :-   const array_name = []
                                    array_name[index] = value;

                        EXAMPLE :-  const arr4 = [];
                                    arr4[10]= "raj";
                                    console.log(arr4); 







3. ACCESS ELEMENT FROM an array :- 

               arayName[index]    :- get the element of an array at index.
                                    
                                    
                        SYNTAX :-   arayName[index]
                        
                        EXAMPLE :-  const arr1 = ["abhay" , 2 , {"key21" : "value21" , "key22":"value22"} , ["value30" , "value31" , "value33"]];
                                    console.log(arr1);              //  output:-  ["abhay" , 2 , {"key21" : "value21" , "key22":"value22"} , ["value30" , "value31" , "value33"]];

                                    console.log(arr1[0]);           //  output:- abhay
                                    console.log(arr1[1]);           //  output:- 2
                                    
                                    console.log(arr1[2]);           //  output:- {key21: 'value21', key22: 'value22'}
                                    console.log(arr1[2].key21);     //  output:- value21
                                    console.log(arr1[2]["key22"]);  //  output:- value22

                                    console.log(arr1[3]);           //  output:- ['value30', 'value31', 'value33']
                                    console.log(arr1[3][0]);        //  output:- value30
                                    console.log(arr1[3][1]);        //  output:- value31
                                    console.log(arr1[3][2]);        //  output:- value33








4. ADDING OR REMOVING SINGLE ELEMENTS AT THE BEGINNING OR END

            pop()	                Removes the last element of an array, and returns that element
            push()	                Adds elements to the end of an array, and returns the new length

            shift()	                Removes the first element of an array, and returns that element
            unshift()	            add elements to the beginning of the array (in place) , and returns the new length.
                                    

                        SYNTAX :-   arrayName.push(item1, item2, ..., itemX)
                                    arrayName.pop()

                                    arrayName.unshift(item1, item2, ..., itemX)
                                    arrayName.shift()



                        EXAMPLE :-  const arr = ["b", "c", "d"];
                                    arr.push("e"); // returns 4; arr is now ["b", "c", "d", "e"]
                                    arr.pop(); // returns "e"; arr is now ["b", "c", "d"]
                                    arr.unshift("a"); // returns 4; arr is now ["a", "b", "c", "d"]
                                    arr.shift(); // returns "a"; arr is now ["b", "c", "d"]










5. ADDING MULTIPLE ELEMENTS AT THE END and ADD TWO ARRAY

            concat()	            Joins two or more arrays, and returns a copy of the joined arrays
                                    

                        SYNTAX :-   array1.concat(array2, array3, ..., arrayX)



                        EXAMPLE :-  const arr1 = ["Cecilie", "Lone"];
                                    const arr2 = ["Emil", "Tobias", "Linus"];
                                    const arr3 = ["Robin"];
                                    const children = arr1.concat(arr2,arr3);
                                    console.log(children);







6. GETTING A SUBARRAY

            slice()	                Selects a part of an array, and returns the new array
                                    

                        SYNTAX :-   arrayName.slice()
                                    arrayName.slice(start)          // create new subarray from stating-point to last-index of an original array
                                    arrayName.slice(start, end)     // create new subarray from stating-point to ending-point of an original array



                        EXAMPLE :-  const animals = ['ant', 'bison', 'camel', 'duck', 'elephant'];

                                    console.log(animals.slice(2));
                                    // expected output: Array ["camel", "duck", "elephant"]
                                    
                                    console.log(animals.slice(2, 4));
                                    // expected output: Array ["camel", "duck"]

                                    console.log(animals.slice(1, 5));
                                    // expected output: Array ["bison", "camel", "duck", "elephant"]

                                    console.log(animals.slice(-2));
                                    // expected output: Array ["duck", "elephant"]

                                    console.log(animals.slice(2, -1));
                                    // expected output: Array ["camel", "duck"]

                                    console.log(animals.slice());
                                    // expected output: Array ["ant", "bison", "camel", "duck", "elephant"]







7. ADDING OR REMOVING ELEMENTS AT ANY POSITION

            splice()	            Adds/Removes elements from an array
                                    

                        SYNTAX :-   arrayName.splice(start)                                     // remove elements from starting-point from an array
                                    arrayName.splice(start, deleteCount)                        // remove deleteCount(1,2..) element from starting-point
                                    arrayName.splice(start, deleteCount, item1)                 // remove deleteCount(1,2..) element from starting-point and add item1 at starting-point
                                    arrayName.splice(start, deleteCount, item1, item2, itemN)   // remove deleteCount(1,2..) element from starting-point and add item1,item2... at starting-point

                        NOTE:-      The first argument is the index you want to start modifying; 
                                    the second argument is the number of elements to remove 
                                    (use 0 if you don’t want to remove any elements), 
                                    and the remaining arguments are the elements to be added


                        EXAMPLE :-  const arr = [1, 5, 7];
                                    arr.splice(1, 0, 2, 3, 4); // returns []; arr is now [1, 2, 3, 4, 5, 7]
                                    arr.splice(5, 0, 6); // returns []; arr is now [1, 2, 3, 4, 5, 6, 7]
                                    arr.splice(1, 2); // returns [2, 3]; arr is now [1, 4, 5, 6, 7]
                                    arr.splice(2, 1, 'a', 'b'); // returns [5]; arr is now [1, 4, 'a', 'b', 6, 7]

                        EXAMPLE :-  // Remove 0 (zero) elements before index 2, and insert "drum"
                                    let myFish = ['angel', 'clown', 'mandarin', 'sturgeon']
                                    let removed = myFish.splice(2, 0, 'drum')

                                    // myFish is ["angel", "clown", "drum", "mandarin", "sturgeon"]
                                    // removed is [], no elements removed

                        EXAMPLE :-  // Remove 0 (zero) elements before index 2, and insert "drum" and "guitar"
                                    let myFish = ['angel', 'clown', 'mandarin', 'sturgeon']
                                    let removed = myFish.splice(2, 0, 'drum', 'guitar')

                                    // myFish is ["angel", "clown", "drum", "guitar", "mandarin", "sturgeon"]
                                    // removed is [], no elements removed

                        EXAMPLE :-  // Remove 1 element at index 3
                                    let myFish = ['angel', 'clown', 'drum', 'mandarin', 'sturgeon']
                                    let removed = myFish.splice(3, 1)

                                    // myFish is ["angel", "clown", "drum", "sturgeon"]
                                    // removed is ["mandarin"]

                        EXAMPLE :-  // Remove 1 element at index 2, and insert "trumpet"
                                    let myFish = ['angel', 'clown', 'drum', 'sturgeon']
                                    let removed = myFish.splice(2, 1, 'trumpet')

                                    // myFish is ["angel", "clown", "trumpet", "sturgeon"]
                                    // removed is ["drum"]

                        EXAMPLE :-  // Remove 2 elements from index 0, and insert "parrot", "anemone" and "blue"
                                    let myFish = ['angel', 'clown', 'trumpet', 'sturgeon']
                                    let removed = myFish.splice(0, 2, 'parrot', 'anemone', 'blue')

                                    // myFish is ["parrot", "anemone", "blue", "trumpet", "sturgeon"]
                                    // removed is ["angel", "clown"]

                        EXAMPLE :-  // Remove 2 elements, starting from index 2
                                    let myFish = ['parrot', 'anemone', 'blue', 'trumpet', 'sturgeon']
                                    let removed = myFish.splice(2, 2)

                                    // myFish is ["parrot", "anemone", "sturgeon"]
                                    // removed is ["blue", "trumpet"]

                        EXAMPLE :-  // Remove 1 element from index -2
                                    let myFish = ['angel', 'clown', 'mandarin', 'sturgeon']
                                    let removed = myFish.splice(-2, 1)

                                    // myFish is ["angel", "clown", "sturgeon"]
                                    // removed is ["mandarin"]

                        EXAMPLE :-  // Remove all elements, starting from index 2
                                    let myFish = ['angel', 'clown', 'mandarin', 'sturgeon']
                                    let removed = myFish.splice(2)

                                    // myFish is ["angel", "clown"]
                                    // removed is ["mandarin", "sturgeon"] 







8. CUTTING AND REPLACING WITHIN AN ARRAY

            copyWithin()	        Copies array elements within the array, to and from specified positions
                                    

                        SYNTAX :-   arrayName.copyWithin(target)
                                    arrayName.copyWithin(target, start)
                                    arrayName.copyWithin(target, start, end)

                        NOTE:-      copyWithin, that takes a sequence of elements from an
                                    array and copies them, in place, to a different part of the array,
                                    overwriting whatever elements are there. 
                                    The first argument is where to copy to (the target), the second
                                    argument is where to start copying from, 
                                    and the final (optional) argument is where to stop copying from. 
                                    As with slice, you can use negative numbers for the start and
                                    end indexes, and they count backward from the end of the array. 


                        EXAMPLE :-  const arr = [1, 2, 3, 4];
                                    arr.copyWithin(1, 2);       // arr is now [1, 3, 4, 4]
                                    arr.copyWithin(2, 0, 2);    // arr is now [1, 3, 1, 3]
                                    arr.copyWithin(0, -3, -1);  // arr is now [3, 1, 1, 3]

                        EXAMPLE :-  const array1 = ['a', 'b', 'c', 'd', 'e'];

                                    // copy to index 0 the element at index 3
                                    console.log(array1.copyWithin(0, 3, 4));
                                    // expected output: Array ["d", "b", "c", "d", "e"]

                                    // copy to index 1 all elements from index 3 to the end
                                    console.log(array1.copyWithin(1, 3));
                                    // expected output: Array ["d", "d", "e", "d", "e"]

                        EXAMPLE :-  [1, 2, 3, 4, 5].copyWithin(-2)
                                    // [1, 2, 3, 1, 2]

                                    [1, 2, 3, 4, 5].copyWithin(0, 3)
                                    // [4, 5, 3, 4, 5]

                                    [1, 2, 3, 4, 5].copyWithin(0, 3, 4)
                                    // [4, 2, 3, 4, 5]

                                    [1, 2, 3, 4, 5].copyWithin(-2, -3, -1)
                                    // [1, 2, 3, 3, 4]

                                    [].copyWithin.call({length: 5, 3: 1}, 0, 3)
                                    // {0: 1, 3: 1, length: 5}

                                    // ES2015 Typed Arrays are subclasses of Array
                                    var i32a = new Int32Array([1, 2, 3, 4, 5])

                                    i32a.copyWithin(0, 2)
                                    // Int32Array [3, 4, 5, 4, 5]

                                    // On platforms that are not yet ES2015 compliant:
                                    [].copyWithin.call(new Int32Array([1, 2, 3, 4, 5]), 0, 3, 4);
                                    // Int32Array [4, 2, 3, 4, 5]







10. FILLING AN ARRAY WITH A SPECIC VALUE

            fill()	                Fill the elements in an array with a static value
                                    

                        SYNTAX :-   arrayName.fill(value)               // fill value at every-index
                                    arrayName.fill(value, start)        // fill value from start-Point to last at every-index
                                    arrayName.fill(value, start, end)   // fill value from start-Point to end-Point at every-index

                        NOTE:-      fill, which allows you to set any number of elements 
                                    with a fixed value (in place). This is particularly useful 
                                    when used with the Array constructor 
                                    (which allows you to specify the initial size of the array). 
                                    You can optionally specify a start and end index 
                                    if you only want to fill part of the array 
                                    (negative indexes work as expected). 


                        EXAMPLE :-  const arr = new Array(5).fill(1); // arr initialized to [1, 1, 1, 1, 1]
                                    arr.fill("a"); // arr is now ["a", "a", "a", "a", "a"]
                                    arr.fill("b", 1); // arr is now ["a", "b", "b", "b", "b"]
                                    arr.fill("c", 2, 4); // arr is now ["a", "b", "c", "c", "b"]
                                    arr.fill(5.5, -4); // arr is now ["a", 5.5, 5.5, 5.5, 5.5]
                                    arr.fill(0, -3, -1); // arr is now ["a", 5.5, 0, 0, 5.5]

                        EXAMPLE :-  const array1 = [1, 2, 3, 4];

                                    // fill with 0 from position 2 until position 4
                                    console.log(array1.fill(0, 2, 4));
                                    // expected output: [1, 2, 0, 0]

                                    // fill with 5 from position 1
                                    console.log(array1.fill(5, 1));
                                    // expected output: [1, 5, 5, 5]

                                    console.log(array1.fill(6));
                                    // expected output: [6, 6, 6, 6]







11. REVERSE AN ARRAY 

            reverse()	            Reverses the order of the elements in an array
                                    

                        SYNTAX :-   arrayName.reverse()         // reverse of an original array

                        EXAMPLE :-  const array1 = ['one', 'two', 'three'];
                                    console.log('array1:', array1);
                                    // expected output: "array1:" Array ["one", "two", "three"]

                                    const reversed = array1.reverse();
                                    console.log('reversed:', reversed);
                                    // expected output: "reversed:" Array ["three", "two", "one"]

                                    // Careful: reverse is destructive -- it changes the original array.
                                    console.log('array1:', array1);
                                    // expected output: "array1:" Array ["three", "two", "one"]


                        EXAMPLE :-  // Reversing the elements in an array-like object
                                    const obj = {0: 1, 1: 2, 2: 3, length: 3};
                                    console.log(obj); // {0: 1, 1: 2, 2: 3, length: 3}

                                    Array.prototype.reverse.call(obj); //same syntax for using apply()
                                    console.log(obj); // {0: 3, 1: 2, 2: 1, length: 3}







12. SORT AN ARRAY 

            sort()	                Sorts the elements of an array
                                    

                        SYNTAX :-   arrayName.sort(compareFunction)         // sorting of an original array in ascending-order

                                    // Functionless
                                     arrayName.sort()

                                    // Arrow function
                                     arrayName.sort((a, b) => { /* ....writingFunction... */ } )

                                    // Compare function
                                     arrayName.sort(compareFn)

                                    // Inline compare function
                                     arrayName.sort(function compareFn(a, b) { /* ....writingFunction... */ })

                        NOTE :-     if you want to sort in descending- then
                                    step-1 :- sort an array  --> let arraySort = arrayOriginal.sort(compareFunction) 
                                    step-2 :- reverse an array  --> let descendingArray = arraySort.reverse()


                        EXAMPLE :-  const array1 = ['one', 'two', 'three'];
                                    console.log('array1:', array1);
                                    // expected output: "array1:" Array ["one", "two", "three"]

                                    const reversed = array1.reverse();
                                    console.log('reversed:', reversed);
                                    // expected output: "reversed:" Array ["three", "two", "one"]

                                    // Careful: reverse is destructive -- it changes the original array.
                                    console.log('array1:', array1);
                                    // expected output: "array1:" Array ["three", "two", "one"]


                        EXAMPLE :-  const points = [40, 100, 1, 5, 25, 10];

                                    // Sort the numbers in descending order:
                                    points.sort(function(a, b){return b-a});

                                    let highest = points[0];
                                    let lowest = points[points.length-1];


                        EXAMPLE :-  // Creating, displaying, and sorting an array

                                    let stringArray = ['Blue', 'Humpback', 'Beluga'];
                                    let numericStringArray = ['80', '9', '700'];
                                    let numberArray = [40, 1, 5, 200];
                                    let mixedNumericArray = ['80', '9', '700', 40, 1, 5, 200];

                                    function compareNumbers(a, b) {
                                      return a - b;
                                    }

                                    stringArray.join(); // 'Blue,Humpback,Beluga'
                                    stringArray.sort(); // ['Beluga', 'Blue', 'Humpback']

                                    numberArray.join(); // '40,1,5,200'
                                    numberArray.sort(); // [1, 200, 40, 5]
                                    numberArray.sort(compareNumbers); // [1, 5, 40, 200]

                                    numericStringArray.join(); // '80,9,700'
                                    numericStringArray.sort(); // [700, 80, 9]
                                    numericStringArray.sort(compareNumbers); // [9, 80, 700]

                                    mixedNumericArray.join(); // '80,9,700,40,1,5,200'
                                    mixedNumericArray.sort(); // [1, 200, 40, 5, '700', '80', '9']
                                    mixedNumericArray.sort(compareNumbers); // [1, 5, '9', 40, '80', 200, '700']






13. COVERSION IN  ARRAY 

            split()	                ---->CONVERSION string to array     Converts string to a an array, and returns the result
            toString()	            ---->CONVERSION array to string     Converts an array to a string, and returns the result
            
            join()	                ---->CONVERSION array to string     Joins all elements of an array into a string 



            new Map(Object.entries(objectName));	            ---->CONVERSION object to MAP



            entries()	            ---->CONVERSION object to array     Returns a key/value pair Array Iteration Object
            
            keys()	                ---->CONVERSION object to array     Returns a Array Iteration Object, containing the keys of the original array
            values()   :-           ---->CONVERSION object to array     Returns a Array Iteration Object, containing the values of the original array         
            
            fromEntries()           ---->CONVERSION array to object     Returns a key/value pair Array Iteration Object
               
               

            from()	                ---->CONVERSION array-like-object(map,object,set)  to  array     Creates an array from an array-like or iterable object.

                       
            
            
                                    

                        SYNTAX :-   1. // split
                                    stringName.split()
                                    stringName.split(separator)
                                    stringName.split(separator, limit)

                        SYNTAX :-   2. // toString
                                    arrayName.toString()

                        SYNTAX :-   3. // join
                                    arrayName.join()
                                    arrayName.join(separator)

                        SYNTAX :-   4. // entries
                                    Object.entries(objectName)                  //---> object to array [[key1 ,value1], [key2 ,value2],.... ]

                                    new Map(Object.entries(objectName));        //---> object to map {"key1" => value1, "key2" => value}

                        SYNTAX :-   5. // keys
                                    Object.keys(objectName)

                        SYNTAX :-   6. // values
                                    Object.values(objectName)

                        SYNTAX :-   7. // fromEntries
                                    Object.fromEntries(iterable);

                        SYNTAX :-   8. // from

                                    Array.from(stringName)                                                         --> string to array
                                    
                                    Array.from(setName)                                                            --> set to array
                                    
                                    Array.from(mapName)                                                            --> map to array
                                    Array.from(mapName.values())                                                   --> map-values into array
                                    Array.from(mapName.keys())                                                     --> map-keys into array
                                    
                                    Array.from(nodeName, image => mapFn)                                           --> node-List to array
                                    
                                    Array.from(arrayOriginal, (element) => { /* ....writingFunction... */ } )      --> array to modify-array
                                                                    
                                    function functionName() {return Array.from(arguments); }                       --> function-Argument to array
                                  

                                    // Arrow function
                                    Array.from(arrayLike, (element) => { /* ....writingFunction... */ } )
                                    Array.from(arrayLike, (element, index) => { /* ....writingFunction... */ } )

                                    // Mapping function
                                    Array.from(arrayLike, mapFn)
                                    Array.from(arrayLike, mapFn, thisArg)

                                    // Inline mapping function
                                    Array.from(arrayLike, function mapFn(element) { /* ....writingFunction... */ })
                                    Array.from(arrayLike, function mapFn(element, index) { /* ....writingFunction... */ })
                                    Array.from(arrayLike, function mapFn(element) { /* ....writingFunction... */ }, thisArg)
                                    Array.from(arrayLike, function mapFn(element, index) { /* ....writingFunction... */ }, thisArg)



                        EXAMPLE :-    // Example of split    ---> string to array

                                    const str = 'The quick brown fox jumps over the lazy dog.';
                                    const words = str.split(' ');
                                    console.log(words[3]);          // expected output: "fox"
                                    const chars = str.split('');
                                    console.log(chars[8]);          // expected output: "k"
                                    const strCopy = str.split();
                                    console.log(strCopy);           // expected output: Array ["The quick brown fox jumps over the lazy dog."]

                                    // Removing spaces from a string
                                    const names = 'Harry Trump ;Fred Barney; Helen Rigby ; Bill Abel ;Chris Hand '
                                    console.log(names)                              // output:-  Harry Trump ;Fred Barney; Helen Rigby ; Bill Abel ;Chris Hand
                                    const re = /\s*(?:;|$)\s*/
                                    const nameList = names.split(re)
                                    console.log(nameList)                           // output:- [ "Harry Trump", "Fred Barney", "Helen Rigby", "Bill Abel", "Chris Hand", "" ]
                                   
                                    // Returning a limited number of splits
                                    const myString = 'Hello World. How are you doing?'
                                    const splits = myString.split(' ', 3)
                                    console.log(splits)                             // output:- ["Hello", "World.", "How"]

                                    // Splitting with a RegExp to include parts of the separator in the result
                                    const myString = 'Hello 1 word. Sentence number 2.'
                                    const splits = myString.split(/(\d)/)
                                    console.log(splits)                             // output:- [ "Hello ", "1", " word. Sentence number ", "2", "." ]




                        EXAMPLE :-    // Example of toString    ---> array to string

                                    const array1 = [1, 2, 'a', '1a'];
                                    console.log(array1.toString());                 // output:- "1,2,a,1a"

                                    


                        EXAMPLE :-    // Example of join    ---> array to string

                                    const elements = ['Fire', 'Air', 'Water'];
                                    console.log(elements.join());               // expected output: "Fire,Air,Water"
                                    console.log(elements.join(''));             // expected output: "FireAirWater"
                                    console.log(elements.join('-'));            // expected output: "Fire-Air-Water"
                                    
                                    const a = ['Wind', 'Water', 'Fire'];
                                    a.join();                                   // expected output: 'Wind,Water,Fire'
                                    a.join(', ');                               // expected output: 'Wind, Water, Fire'
                                    a.join(' + ');                              // expected output: 'Wind + Water + Fire'
                                    a.join('');                                 // expected output: 'WindWaterFire'

                                    



                        EXAMPLE :-    // Example of entries     ---> object to map {"key1" => value1, "key2" => value}

                                    const obj = { foo: 'bar', baz: 42 };
                                    const map = new Map(Object.entries(obj));
                                    console.log(map); // Map(2) {"foo" => "bar", "baz" => 42}                   




                        EXAMPLE :-    // Example of entries     ---> object to array [[key1 ,value1], [key2 ,value2],.... ]
                        
                                    const obj = { foo: 'bar', baz: 42 };
                                    console.log(Object.entries(obj)); // [ ['foo', 'bar'], ['baz', 42] ]

                                    // array like object
                                    const obj = { 0: 'a', 1: 'b', 2: 'c' };
                                    console.log(Object.entries(obj)); // [ ['0', 'a'], ['1', 'b'], ['2', 'c'] ]

                                    // array like object with random key ordering
                                    const anObj = { 100: 'a', 2: 'b', 7: 'c' };
                                    console.log(Object.entries(anObj)); // [ ['2', 'b'], ['7', 'c'], ['100', 'a'] ]

                                    // getFoo is property which isn't enumerable
                                    const myObj = Object.create({}, { getFoo: { value() { return this.foo; } } });
                                    myObj.foo = 'bar';
                                    console.log(Object.entries(myObj)); // [ ['foo', 'bar'] ]

                                    // non-object argument will be coerced to an object
                                    console.log(Object.entries('foo')); // [ ['0', 'f'], ['1', 'o'], ['2', 'o'] ]

                                    // returns an empty array for any primitive type except for strings (see the above example), since primitives have no own properties
                                    console.log(Object.entries(100)); // [ ]

                                    // iterate through key-value gracefully
                                    const obj = { a: 5, b: 7, c: 9 };
                                    for (const [key, value] of Object.entries(obj)) {
                                      console.log(`${key} ${value}`); // "a 5", "b 7", "c 9"
                                    }

                                    // Or, using array extras
                                    Object.entries(obj).forEach(([key, value]) => {
                                      console.log(`${key} ${value}`); // "a 5", "b 7", "c 9"
                                    });                                    




                        EXAMPLE :-  // Example of keys

                                    // simple array
                                    const arr = ['a', 'b', 'c'];
                                    console.log(Object.keys(arr)); // console: ['0', '1', '2']

                                    // array-like object
                                    const obj = { 0: 'a', 1: 'b', 2: 'c' };
                                    console.log(Object.keys(obj)); // console: ['0', '1', '2']

                                    // array-like object with random key ordering
                                    const anObj = { 100: 'a', 2: 'b', 7: 'c' };
                                    console.log(Object.keys(anObj)); // console: ['2', '7', '100']

                                    // getFoo is a property which isn't enumerable
                                    const myObj = Object.create({}, {
                                      getFoo: {
                                        value: function () { return this.foo; }
                                      }
                                    });
                                    myObj.foo = 1;
                                    console.log(Object.keys(myObj)); // console: ['foo']



                        EXAMPLE :-  // Example of values

                                    //simple array
                                    const obj = { foo: 'bar', baz: 42 };
                                    console.log(Object.values(obj)); // ['bar', 42]

                                    // Array-like object
                                    const arrayLikeObj1 = { 0: 'a', 1: 'b', 2: 'c' };
                                    console.log(Object.values(arrayLikeObj1 )); // ['a', 'b', 'c']

                                    // Array-like object with random key ordering
                                    // When using numeric keys, the values are returned in the keys' numerical order
                                    const arrayLikeObj2 = { 100: 'a', 2: 'b', 7: 'c' };
                                    console.log(Object.values(arrayLikeObj2 )); // ['b', 'c', 'a']

                                    // getFoo is property which isn't enumerable
                                    const my_obj = Object.create({}, { getFoo: { value: function() { return this.foo; } } });
                                    my_obj.foo = 'bar';
                                    console.log(Object.values(my_obj)); // ['bar']

                                    // non-object argument will be coerced to an object
                                    console.log(Object.values('foo')); // ['f', 'o', 'o']



                        EXAMPLE :-  // Example of fromEntries

                                    const entries = [ ['foo', 'bar'] , ['baz', 42] ];
                                    console.log(entries);                       // output:- Array [Array ["foo", "bar"], Array ["baz", 42]]
                                                
                                    const obj = Object.fromEntries(entries);
                                    console.log(obj);                           // output:- Object { foo: "bar", baz: 42 }

  



                        EXAMPLE :-  // Example of from

                                    // --> string to array
                                    console.log(Array.from('foo kumar'));               // expected output: Array ["f", "o", "o"]
                                    
                                    // --> array to modify-array
                                    console.log(Array.from([1, 2, 3], x => x + x));     // expected output: Array [2, 4, 6]

                                    // --> set to array
                                    const set = new Set(['foo', 'bar', 'baz', 'foo']);
                                    Array.from(set);                                    // [ "foo", "bar", "baz" ]

                                    // --> map to array
                                    const map = new Map([[1, 2], [2, 4], [4, 8]]);
                                    Array.from(map);                                    // [[1, 2], [2, 4], [4, 8]]
                                    
                                    // --> map-values to array
                                    const mapper = new Map([['1', 'a'], ['2', 'b']]);
                                    Array.from(mapper.values());                        // ['a', 'b'];

                                    // --> map-keys to array
                                    const mapper = new Map([['1', 'a'], ['2', 'b']]);
                                    Array.from(mapper.keys());                          // ['1', '2'];

                                    // --> node-List to array
                                    // Create an array based on a property of DOM Elements
                                    const images = document.getElementsByTagName('img');
                                    const sources = Array.from(images, image => image.src);
                                    const insecureSources = sources.filter(link => link.startsWith('http://'));

                                    // --> function-Argument to array
                                    function f() {
                                      return Array.from(arguments);
                                    }
                                    f(1, 2, 3);                                         // // [ 1, 2, 3 ]

                                    // --> Using arrow functions and Array.from()
                                    // --> Sequence generator (range)
                                    // Using an arrow function as the map function to
                                    // manipulate the elements
                                    Array.from([1, 2, 3], x => x + x);                  // [2, 4, 6]

                                    // Generate a sequence of numbers
                                    // Since the array is initialized with `undefined` on each position,
                                    // the value of `v` below will be `undefined`
                                    Array.from({length: 5}, (v, i) => i);               // [0, 1, 2, 3, 4]

                                    // --> Sequence generator (range)
                                    // Sequence generator function (commonly referred to as "range", e.g. Clojure, PHP etc)
                                    const range = (start, stop, step) => Array.from({ length: (stop - start) / step + 1}, (_, i) => start + (i * step));

                                    // Generate numbers range 0..4
                                    range(0, 4, 1);                                 // [0, 1, 2, 3, 4]

                                    // Generate numbers range 1..10 with step of 2
                                    range(1, 10, 2);                                // [1, 3, 5, 7, 9]

                                    // Generate the alphabet using Array.from making use of it being ordered as a sequence
                                    range('A'.charCodeAt(0), 'Z'.charCodeAt(0), 1).map(x => String.fromCharCode(x));`       // ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]


                                    









14. ARRAY SEARCHING

            find()	                Returns the value of the first element in an array that pass a test
            findIndex()	            Returns the index of the first element in an array that pass a test  S:-
            indexOf()	            Search the array for an element and returns its position    S:- return first index  F:- -1
            lastIndexOf()	        Search the array for an element, starting at the end, and returns its position
            some()	                Checks if any of the elements in an array pass a test
            every()	                Checks if every element in an array pass a test

                                    

                        SYNTAX :-   1. //  indexOf
                                    arrayName.indexOf(searchElement)                    // search from index= 0   --> in ascending order                 // S:- index     F:- -1
                                    arrayName.indexOf(searchElement, fromIndex)         // search from index= fromIndex   --> in ascending order         // S:- index     F:- -1 

                        NOTE:-      indexOf simply returns the index of the first element 
                                    it finds that is strictly equal to what you’re looking for.

                                    If you only want to search a portion of an array, 
                                    you can specify an optional start index. 

                                    If indexOf (or lastIndexOf) returns –1, it wasn’t able to find a match:

                        SYNTAX :-   2. //  lastIndexOf
                                    arrayName.lastIndexOf(searchElement)                  // search from index= 0   --> in descending order                // S:- index     F:- -1
                                    arrayName.lastIndexOf(searchElement, fromIndex)       // search from index= fromIndex   --> in descending order        // S:- index     F:- -1 

                        NOTE:-      lastIndexOf that searches from end, and returns the last index 
                                    that matches what you’re looking for                

                                    If you only want to search a portion of an array, 
                                    you can specify an optional start index. 
                                    
                                    lastIndexOf returns –1, it wasn’t able to find a match:

                        SYNTAX :-   3. //  find

                                    // Arrow function
                                    arrayName.find((element) => { /* ....writingFunction.... */ } ) 
                                    arrayName.find((element, index) => { /* ....writingFunction... */ } )
                                    arrayName.find((element, index, array) => { /* ....writingFunction... */ } )

                                    // Callback function
                                    arrayName.find(callbackFn)
                                    arrayName.find(callbackFn, thisArg)

                                    // Inline callback function
                                    arrayName.find(function(element) { /* ....writingFunction... */ })
                                    arrayName.find(function(element, index) { /* ....writingFunction... */ })
                                    arrayName.find(function(element, index, array){ /* ....writingFunction... */ })
                                    arrayName.find(function(element, index, array) { /* ....writingFunction... */ }, thisArg)

                        NOTE:-      find is like findIndex in that it allows you to specify a function 
                                    to find what you’re looking for, but it returns the element itself 
                                    instead of the index (or null if no such element was found):

                        SYNTAX :-   4. //  findIndexOf

                                    // Arrow function
                                    arrayName.findIndex((element) => { /* ....writingFunction... */ } )                                                 // S:- index     F:- -1
                                    arrayName.findIndex((element, index) => { /* ....writingFunction... */ } )                                          // S:- index     F:- -1
                                    arrayName.findIndex((element, index, array) => { /* ....writingFunction... */ } )                                   // S:- index     F:- -1

                                    // Callback function
                                    arrayName.findIndex(callbackFn)                                                                                     // S:- index     F:- -1
                                    arrayName.findIndex(callbackFn, thisArg)                                                                            // S:- index     F:- -1

                                    // Inline callback function
                                    arrayName.findIndex(function(element) { /* ....writingFunction... */ })                                             // S:- index     F:- -1
                                    arrayName.findIndex(function(element, index) { /* ....writingFunction... */ })                                      // S:- index     F:- -1
                                    arrayName.findIndex(function(element, index, array){ /* ....writingFunction... */ })                                // S:- index     F:- -1
                                    arrayName.findIndex(function(element, index, array) { /* ....writingFunction... */ }, thisArg)                      // S:- index     F:- -1

                        NOTE:-      findIndex, it returns an index (or –1 if there’s no match). 


                        SYNTAX :-   5. //  some

                                    // Arrow function
                                    arrayName.some((element) => { /* ....writingFunction... */ } )
                                    arrayName.some((element, index) => { /* ....writingFunction... */ } )
                                    arrayName.some((element, index, array) => { /* ....writingFunction... */ } )

                                    // Callback function
                                    arrayName.some(callbackFn)
                                    arrayName.some(callbackFn, thisArg)

                                    // Inline callback function
                                    arrayName.some(function(element) { /* ....writingFunction... */ })
                                    arrayName.some(function(element, index) { /* ....writingFunction... */ })
                                    arrayName.some(function(element, index, array){ /* ....writingFunction... */ })
                                    arrayName.some(function(element, index, array) { /* ....writingFunction... */ }, thisArg)

                        NOTE:-      "some" returns true if it finds an element that meets the criteria 
                                    (all it needs is one; it’ll stop looking after it finds the first one), 
                                    and false otherwise


                        SYNTAX :-   6. //  every  

                                    // Arrow function
                                    arrayName.every((element) => { /* ....writingFunction... */ } )
                                    arrayName.every((element, index) => { /* ....writingFunction... */ } )
                                    arrayName.every((element, index, array) => { /* ....writingFunction... */ } )

                                    // Callback function
                                    arrayName.every(callbackFn)
                                    arrayName.every(callbackFn, thisArg)

                                    // Inline callback function
                                    arrayName.every(function(element) { /* ....writingFunction... */ })
                                    arrayName.every(function(element, index) { /* ....writingFunction... */ })
                                    arrayName.every(function(element, index, array){ /* ....writingFunction... */ })
                                    arrayName.every(function(element, index, array) { /* ....writingFunction... */ }, thisArg)


                        NOTE:-      "every" returns true if every element in the array passes 
                                    the criteria, and false otherwise. 
                                    "every" will stop looking and return false if it finds an 
                                    element that doesn’t match the criteria; otherwise, 
                                    it will have to scan the entire array:


                        EXAMPLE :-  //Example of indexOf
                                    const beasts = ['ant', 'bison', 'camel', 'duck', 'bison'];

                                    console.log(beasts.indexOf('bison'));
                                    // expected output: 1

                                    // start from index 2
                                    console.log(beasts.indexOf('bison', 2));
                                    // expected output: 4

                                    console.log(beasts.indexOf('giraffe'));
                                    // expected output: -1



                                    const o = { name: "Jerry" };
                                    const arr = [1, 5, "a", o, true, 5, [1, 2], "9"];
                                    arr.indexOf(5); // returns 1
                                    arr.lastIndexOf(5); // returns 5
                                    arr.indexOf("a"); // returns 2
                                    arr.lastIndexOf("a"); // returns 2
                                    arr.indexOf({ name: "Jerry" }); // returns -1
                                    arr.indexOf(o); // returns 3
                                    arr.indexOf([1, 2]); // returns -1
                                    arr.indexOf("9"); // returns 7
                                    arr.indexOf(9); // returns -1
                                    arr.indexOf("a", 5); // returns -1
                                    arr.indexOf(5, 5); // returns 5
                                    arr.lastIndexOf(5, 4); // returns 1
                                    arr.lastIndexOf(true, 3); // returns -1



                        EXAMPLE :-  //Example of lastIndexOf
                                    
                                    const numbers = [2, 5, 9, 2];
                                    numbers.lastIndexOf(2);     // 3
                                    numbers.lastIndexOf(7);     // -1
                                    numbers.lastIndexOf(2, 3);  // 3
                                    numbers.lastIndexOf(2, 2);  // 0
                                    numbers.lastIndexOf(2, -2); // 0
                                    numbers.lastIndexOf(2, -1); // 3

                                    
                        EXAMPLE :-  //Example of find

                                    const array1 = [5, 12, 8, 130, 44];
                                    const found = array1.find(element => element > 10);
                                    console.log(found);
                                    // expected output: 12


                                    const arr = [{ id: 5, name: "Judith" }, { id: 7, name: "Francis" }];
                                    arr.find(o => o.id === 5); // returns object { id: 5, name: "Judith" }
                                    arr.find(o => o.id === 2); // returns null


                                    const arr = [1, 17, 16, 5, 4, 16, 10, 3, 49];
                                    arr.find((x, i) => i > 2 && Number.isInteger(Math.sqrt(x))); // returns 4


                                    class Person {
                                     constructor(name) {
                                     this.name = name;
                                     this.id = Person.nextId++;
                                     }
                                    }
                                    Person.nextId = 0;
                                    const jamie = new Person("Jamie"),
                                     juliet = new Person("Juliet"),
                                     peter = new Person("Peter"),
                                     jay = new Person("Jay");
                                    const arr = [jamie, juliet, peter, jay];

                                    // option 1: direct comparison of ID:
                                    arr.find(p => p.id === juliet.id); // returns juliet object

                                    // option 2: using "this" arg:
                                    arr.find(p => p.id === this.id, juliet); // returns juliet object


                        EXAMPLE :-  //Example of findIndexOf

                                    const array1 = [5, 12, 8, 130, 44];
                                    const isLargeNumber = (element) => element > 13;
                                    console.log(array1.findIndex(isLargeNumber));
                                    // expected output: 3


                                    const arr = [{ id: 5, name: "Judith" }, { id: 7, name: "Francis" }];
                                    arr.findIndex(o => o.id === 5); // returns 0
                                    arr.findIndex(o => o.name === "Francis"); // returns 1
                                    arr.findIndex(o => o === 3); // returns -1
                                    arr.findIndex(o => o.id === 17); // returns -1


                        EXAMPLE :-  //Example of some
                                    const arr = [5, 7, 12, 15, 17];
                                    arr.some(x => x%2===0); // true; 12 is even
                                    arr.some(x => Number.isInteger(Math.sqrt(x))); // false; no squares

                                    // Testing value of array elements
                                    function isBiggerThan10(element, index, array) {
                                      return element > 10;
                                    }

                                    [2, 5, 8, 1, 4].some(isBiggerThan10);  // false
                                    [12, 5, 8, 1, 4].some(isBiggerThan10); // true

                                    // Testing array elements using arrow functions
                                    [2, 5, 8, 1, 4].some(x => x > 10);  // false
                                    [12, 5, 8, 1, 4].some(x => x > 10); // true


                        EXAMPLE :-  //Example of every
                                    const arr = [4, 6, 16, 36];
                                    arr.every(x => x%2===0); // true; no odd numbers
                                    arr.every(x => Number.isInteger(Math.sqrt(x))); // false; 6 is not square


                        










                                    


                        

                        

                        

                        

                        























JavaScript Array Methods

Method	                        Description
filter()	            Creates a new array with every element in an array that pass a test
forEach()	            Calls a function for each array element
includes()	            Check if an array contains the specified element
isArray()	            Checks whether an object is an array

map()	                Creates a new array with the result of calling a function for each array element
reduce()	            Reduce the values of an array to a single value (going left-to-right)
reduceRight()	        Reduce the values of an array to a single value (going right-to-left)
valueOf()	            Returns the primitive value of an array





JavaScript            Array Properties

Property	                    Description
constructor	            Returns the function that created the Array object's prototype
length	                Sets or returns the number of elements in an array
prototype	            Allows you to add properties and methods to an Array object













2. CREATE an array :- 

               Array() constructor    :- create Array objects.
                                    
                                    // literal constructor
                        SYNTAX :-   const array_name = [item1, item2, ...]; 

3. ACCESS ELEMENT FROM an array :- 

               Array() constructor    :- create Array objects.
                                    
                                    // literal constructor
                        SYNTAX :-   const array_name = [item1, item2, ...];

4. ADDING OR REMOVING SINGLE ELEMENTS AT THE BEGINNING OR END

            pop()	                Removes the last element of an array, and returns that element
            push()	                Adds elements to the end of an array, and returns the new length

            shift()	                Removes the first element of an array, and returns that element
            unshift()	            add elements to the beginning of the array (in place) , and returns the new length.
                                    
                        SYNTAX :-   arrayName.push(item1, item2, ..., itemX)
                                    arrayName.pop()

                                    arrayName.unshift(item1, item2, ..., itemX)
                                    arrayName.shift()

5. ADDING MULTIPLE ELEMENTS AT THE END and ADD TWO ARRAY

            concat()	            Joins two or more arrays, and returns a copy of the joined arrays
                                    

                        SYNTAX :-   array1.concat(array2, array3, ..., arrayX)

6. GETTING A SUBARRAY

            slice()	                Selects a part of an array, and returns the new array              

                        SYNTAX :-   arrayName.slice()
                                    arrayName.slice(start)
                                    arrayName.slice(start, end)

7. ADDING OR REMOVING ELEMENTS AT ANY POSITION

            splice()	            Adds/Removes elements from an array
                                    

                        SYNTAX :-   arrayName.splice(start)
                                    arrayName.splice(start, deleteCount)
                                    arrayName.splice(start, deleteCount, item1)
                                    arrayName.splice(start, deleteCount, item1, item2, itemN)
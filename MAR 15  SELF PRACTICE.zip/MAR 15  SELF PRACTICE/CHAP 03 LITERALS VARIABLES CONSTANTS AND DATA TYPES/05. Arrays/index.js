// CREATE AN ARRAY

const arr1 = ["abhay" , 2 , {"key21" : "value21" , "key22":"value22"} , ["value30" , "value31" , "value33"]];
console.log(arr1); // output:- 

const arr2 = new Array("abhay1" , 21 , {"key211" : "value211" , "key221":"value221"} , ["value301" , "value311" , "value331"]);
console.log(arr2); // output:-   

const arr3 = new Array(5);
console.log(arr3); // output:- 

const arr4 = [];
arr4[10]= "raj";
console.log(arr4); // output:- 



console.log("\n\n")
// ACCESS ELEMENT FROM an array
console.log("ACCESS ELEMENT FROM an array")
console.log(arr1); // output:- 

console.log(arr1[0]); // output:- 
console.log(arr1[1]); // output:- 
                                    
console.log(arr1[2]); // output:- 
console.log(arr1[2].key21); // output:- 
console.log(arr1[2]["key22"]); // output:- 

console.log(arr1[3]); // output:- 
console.log(arr1[3][0]); // output:- 
console.log(arr1[3][1]); // output:- 
console.log(arr1[3][2]); // output:- 






console.log("\n\n")
// ADDING OR REMOVING SINGLE ELEMENTS AT THE BEGINNING OR END
console.log("ADDING OR REMOVING SINGLE ELEMENTS AT THE BEGINNING OR END")
console.log(arr2); // output:- ["item4" ,"itemY" ,"abhay1" ,21 ,{key211: 'value211', key221: 'value221'} ,['value301', 'value311', 'value331'] ,"item1" ,"item2"]

console.log(arr2.push("item1", "item2", "itemX")); // output:- 7
console.log(arr2.pop()); // output:-  itemX

console.log(arr2.unshift("item3", "item4", "itemY")) // output:- 9
console.log(arr2.shift()); // output:- item3






console.log("\n\n")
//ADDING MULTIPLE ELEMENTS AT THE END and ADD TWO ARRAY
console.log("ADDING OR REMOVING SINGLE ELEMENTS AT THE BEGINNING OR END")

const father = ["father1" , "father2" , "father3" , "father4" , "father5" , "father6"] ;
console.log(father); // output:-  ['father1', 'father2', 'father3', 'father4', 'father5', 'father6']

const mother = ["mother1" , "mother2" , "mother3" , "mother4" , "mother5" , "mother6"] ;
console.log(mother); // output:-  ['mother1', 'mother2', 'mother3', 'mother4', 'mother5', 'mother6']

const son = ["son1" , "son2" , "son3" , "son4" , "son5" , "son6"] ;
console.log(son); // output:-  ['son1', 'son2', 'son3', 'son4', 'son5', 'son6']

const daughter = ["daughter1" , "daughter3" , "daughter4" , "daughter4" , "daughter5" , "daughter6"]
console.log(daughter); // output:- ['daughter1', 'daughter3', 'daughter4', 'daughter4', 'daughter5', 'daughter6']

const family = father.concat(mother,son,daughter);
console.log(family); // output :- ['father1', 'father2', 'father3', 'father4', 'father5', 'father6', 'mother1', 'mother2', 'mother3', 'mother4', 'mother5', 'mother6', 'son1', 'son2', 'son3', 'son4', 'son5', 'son6', 'daughter1', 'daughter3', 'daughter4', 'daughter4', 'daughter5', 'daughter6']








console.log("\n\n")
//GETTING A SUBARRAY
console.log("GETTING A SUBARRAY")

const familyPartFather = family.slice(0,5);
console.log(familyPartFather); // output:-  ['father1', 'father2', 'father3', 'father4', 'father5', 'father6']

const familyPartMother = family.slice(6,11);
console.log(familyPartMother); // output:-  ['mother1', 'mother2', 'mother3', 'mother4', 'mother5', 'mother6']

const familyPartSon = family.slice(12,17);
console.log(familyPartSon); // output:- ['son1', 'son2', 'son3', 'son4', 'son5', 'son6']

const familyPartDaughter = family.slice(18);
console.log(familyPartDaughter); // output:- ['daughter1', 'daughter3', 'daughter4', 'daughter4', 'daughter5', 'daughter6']




























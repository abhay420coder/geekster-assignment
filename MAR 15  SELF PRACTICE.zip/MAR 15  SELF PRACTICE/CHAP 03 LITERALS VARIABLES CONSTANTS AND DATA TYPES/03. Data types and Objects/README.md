 PRIMITIVES TYPES AND OBJECTS

 1. In JavaScript, values are either primitives or objects.




 2. PRIMITIVE DATA TYPES

        Primitive types (such as string and number) are immutable.
        
        There are seven primitive types that we will cover:
            • Number
            • String
            • Boolean
            • BigInt
            • Null
            • Undefined
            • Symbol
    




 3. OBJECT TYPES

        Objects can take on different forms and values, and are more chameleon-like.

        Because of their flexibility, objects can be used to construct custom data types. 

        As a matter of fact, JavaScript provides some built-in object types.
               
        There are seven primitive types that we will cover:
            • Object
            • Array
            • Date
            • RegExp
            • Map and WeakMap
            • Set and WeakSet




4. NUMBERS
 
        JavaScript recognizes four types of numeric literal: decimal, binary, octal, and hexadecimal. 
        
        With decimal literals, you can express integers (no decimal), decimal numbers, and numbers 
        in base-10 exponential notation (an abbreviation of scientific notation). 
        
        In addition, there are special values for infinity, negative infinity, and “not a number” 
        (these are not technically numeric literals, but they do result in numeric values, 
        so I am including them here)

                let count = 10;             // integer literal; count is still a double
                const blue = 0x0000ff;      // hexadecimal (hex ff = decimal 255)
                const umask = 0o0022;       // octal (octal 22 = decimal 18)
                const roomTemp = 21.5;      // decimal
                const c = 3.0e6;            // exponential (3.0 × 10^6 = 3,000,000)
                const e = -1.6e-19;         // exponential (-1.6 × 10^-19 = 0.00000000000000000016)
                const inf = Infinity;
                const ninf = -Infinity;
                const nan = NaN;            // "not a number

        

        NOTE:- this is only for information 

        In addition, there are some useful properties of the corresponding Number object that
                     represent important numeric values:
    
                    const small = Number.EPSILON;                   // the smallest value that can be
                                                                    // added to 1 to get a distinct number
                                                                    // larger than 1, approx. 2.2e-16
                    const bigInt = Number.MAX_SAFE_INTEGER;         // the largest representable integer
                    const max = Number.MAX_VALUE;                   // the largest representable number
                    const minInt = Number.MIN_SAFE_INTEGER;         // the smallest representable integer
                    const min = Number.MIN_VALUE;                   // the smallest representable number
                    const nInf = Number.NEGATIVE_INFINITY;          // the same as -Infinity

        
        NOTE:-  •   Number.EPSILON              :-  2.220446049250313e-16
                •   Number.MAX_SAFE_INTEGER     :-  9007199254740991
                •   Number.MAX_VALUE            :-  1.7976931348623157e+308
                •   Number.MIN_SAFE_INTEGER     :-  -9007199254740991
                •   Number.MIN_VALUE            :-  5e-324
                •   Number.NEGATIVE_INFINITY    :-  -Infinity





5. STRINGS 

        A string is simply text data.

        In JavaScript, string literals are represented with single quotes, double quotes, or
        backticks.

        The backtick was introduced in ES6 to enable template strings

        ex:-
                const singleQuotesString = 'i am using single Quotes' ;
                console.log(singleQuotesString) ;

                console.log('i am also using single Quotes') ;


                const doubleQuotesString = "i am using double Quotes" ;
                console.log(doubleQuotesString);

                console.log("i am also using double Quotes") ;


                const backTicksString = "i am using back Ticks" ;
                console.log(backTicksString);

                console.log("i am also using back Ticks") ;





6. ESCAPING

            we can escape quotation marks with a backslash (\), 
            which is a signal to JavaScript that the string is not ending. 
            
            Here’s the preceding example rewritten to use both types
            of quotation marks:
                                const dialog1 = "He looked up and said \"don't do that!\" to Max.";
                                const dialog2 = 'He looked up and said "don\'t do that!" to Max.';


            Then, of course, we get into the chicken-and-egg problem that arises when we want
            to use a backslash in our string. To solve this problem, a backslash can escape itself:
            
            const s = "In JavaScript, use \\ as an escape character in strings.";


        


7. SPECIAL CHARACTERS

                \n   :- new Line                                    ex:- "Line1\nLine2"
                \r   :- Carriage return                             ex:- "Windows line 1\r\nWindows line 2"
                \t   :- Tab                                         ex:- "Speed:\t60kph"

                \0   :- The NUL character (ASCII/Unicode 0)         ex:- "ASCII NUL: \0"
                \v   :- Vertical tab (ASCII/Unicode 11)             ex:- "Vertical tab: \v"
                \b   :- Backspace (ASCII/Unicode 8)                 ex:- "Backspace: \b"
                \f   :- Form feed (ASCII/Unicode 12)                ex:- "Form feed: \f"





8. STRING TEMPLATES 

                String templates provide a shorthand way of injecting values into a
                string. 
                
                String templates use backticks instead of single or double quotes.


                ex:- (without backTicks)
                    let currentTemp = 19.5;
                    // 00b0 is the Unicode code point for the "degree" symbol
                    const message = "The current temperature is " + currentTemp + "\u00b0C";

                    console.log(message);


                ex:- (with backTicks)
                    let currentTemp = 19.5;
                    // 00b0 is the Unicode code point for the "degree" symbol
                    const message = `The current temperature is ${currentTemp}\u00b0C`;

                    console.log(message);     


                NOTE :- Inside a string template, the dollar sign becomes a special character (you can escape it
                        with a backslash):
                        
                        if it’s followed by a value wrapped in curly braces, that value is
                        inserted into the string.                              





9. MULTI-LINE STRING
                    For single-quoted and double-quoted strings, you can escape the newline thusly:
                    
                    const multiline = "line1 \
                                        line2";    
                    console.log(multiline);  // output:-   line1                    line2





                    If you want an actual newline, you’ll have to do this:

                    const multiline2 = "line1 \n\
                                    line2";       
                     console.log(multiline);  // output:-   line1 
                                                            line2


    
                    Multi-Line string using Double-quotes :

                    const multiline = "line1\n" +
                                      "line2\n" +
                                      "line3";



                    Multi-Line String Using Backtick  :

                    const multiline = `line1
                                        line2`;




10. NUMBERS AS STRINGS
                        If you put a number in quotation marks, then 
                        JavaScript will automatically convert strings 
                        that contain numbers to numbers as necessary.

                        ex:- 
                            const result1 = 3 + '30'; // 3 is converted to a string; result is string '330'
                            const result2 = 3 * '30'; // '30' is converted to a number; result is numeric 90




11. SYMBOLS    
                symbols: a new data type representing unique tokens.

                Once you create a symbol, it is unique: 
                it will match no other symbol. In this way, symbols are like
                objects (every object is unique).

                Symbols are created with the Symbol() constructor.
 
                You can optionally provide a description, which is just for convenience:

                const RED = Symbol();
                const ORANGE = Symbol("The color of a sunset!");
                RED === ORANGE // false: every symbol is unique


                NOTE:- I recommend using symbols 
                        whenever you want to have a unique identifier that 
                        you don’t want inadvertently confused with some other identifier.





12. BOOLEANS
                Booleans are value types that have only two possible values: true and false.

                ex:- 
                        let heating = true;
                        let cooling = false;

    



13. NULL AND UNDENED
                null has only one possible value (null), 
            and undefined has only one possible value (undefined). 
            
                Both null and undefined represent something that doesn’t exist, 
                and the fact that there are two separate data types has caused no end of confusion, 
                especially among beginners.


                The general rule of thumb is that :-

                    null is a data type that is available to you, the programmer, 

                and undefined should be reserved for JavaScript itself, 
                    to indicate that something hasn’t been given a value yet.


                ex:- 
                    let currentTemp;            // implicit value of undefined
                    console.log(currentTemp);   // output:-  undefined

                    const targetTemp = null;    // target Temp null -- "not yet known"
                    console.log(targetTemp);    // output:-  null

                    currentTemp = 19.5;         // currentTemp now has value
                    currentTemp = undefined;    // currentTemp appears as if it had never
                                                // been initialized; not recommended
                    console.log(currentTemp3);  // output:-  undefined








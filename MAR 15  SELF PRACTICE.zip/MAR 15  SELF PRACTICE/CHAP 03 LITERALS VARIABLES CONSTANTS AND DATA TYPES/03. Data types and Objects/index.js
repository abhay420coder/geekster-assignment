console.log("Hello Geeks")
console.log("\n\n");  // is code ka use two new line space ke liye kiya gya hai







// PRIMITIVE DATA TYPES  :-    NUMBERS
console.log(" PRIMITIVE DATA TYPES  :-    NUMBERS");

let count = 10;             // integer literal; count is still a double
console.log(count);

const blue = 0x0000ff;      // hexadecimal (hex ff = decimal 255)
console.log(blue);

const umask = 0o0022;       // octal (octal 22 = decimal 18)
console.log(umask);

const roomTemp = 21.5;      // decimal
console.log(roomTemp);

const c = 3.0e6;            // exponential (3.0 × 10^6 = 3,000,000)
console.log(c);

const e = -1.6e-19;         // exponential (-1.6 × 10^-19 = 0.00000000000000000016)
console.log(e);

const inf = Infinity;
console.log(inf);

const ninf = -Infinity;
console.log(ninf);

const nan = NaN;
console.log(nan);

console.log("\n\n");












// NUMBER :- SOME IMPORTANT FIXED VALUE
console.log(" SOME IMPORTANT FIXED VALUE");

const small = Number.EPSILON;                   // the smallest value that can be
                                                // added to 1 to get a distinct number
                                                // larger than 1, approx. 2.2e-16
console.log(small);                             // output:-  2.220446049250313e-16

const bigInt = Number.MAX_SAFE_INTEGER;         // the largest representable integer
console.log(bigInt);                            // output:-  9007199254740991

const max = Number.MAX_VALUE;                   // the largest representable number
console.log(max);                               // output:-  1.7976931348623157e+308

const minInt = Number.MIN_SAFE_INTEGER;         // the smallest representable integer
console.log(minInt);                            // output:-  -9007199254740991

const min = Number.MIN_VALUE;                   // the smallest representable number
console.log(min);                               // output:- 5e-324

const nInf = Number.NEGATIVE_INFINITY;          // the same as -Infinity
console.log(nInf);                              // output:- -Infinity



console.log("\n\n");














// PRIMITIVE DATA TYPES  :-    STRINGS
console.log("PRIMITIVE DATA TYPES  :-    STRINGS ");


const singleQuotesString = 'i am using single Quotes' ;
console.log(singleQuotesString) ;

console.log('i am also using single Quotes') ;


const doubleQuotesString = "i am using double Quotes" ;
console.log(doubleQuotesString);

console.log("i am also using double Quotes") ;


const backTicksString = "i am using back Ticks" ;
console.log(backTicksString);

console.log("i am also using back Ticks") ;

console.log("\n\n");














// ESCAPING 
console.log(" ESCAPING");

const dialog1 = "He looked up and said \"don't do that!\" to Max.";
const dialog2 = 'He looked up and said "don\'t do that!" to Max.';
console.log(dialog1);
console.log(dialog2);

const dialog3 = "In JavaScript, use \\ as an escape character in strings.";
console.log(dialog3);

console.log("\n\n");












// TEMPLATE STRING
console.log("TEMPLATE STRING");

let currentTemp = 19.5;
// 00b0 is the Unicode code point for the "degree" symbol
const message = "The current temperature is " + currentTemp + "\u00b0C";
console.log(message);


let currentTemp2 = 88.5;
// 00b0 is the Unicode code point for the "degree" symbol
const message2 = `The current temperature is ${currentTemp2}\u00b0C`;

console.log(message2);   

console.log("\n\n");












// MULTI-LINE STRING
console.log("MULTI-LINE STRING");

const multiline = "line1\
                    line2";

console.log(multiline);


const multiline2 = "line3 \n\
line4";  

console.log(multiline2); 


const multiline3 = `line5
line6 line7  line8  line9
line10 line11 line12 line13`;

console.log(multiline3); 


const multiline4 = "line14 \n" +
                   "line15 \n" +
                   "line16";
console.log(multiline4); 

console.log("\n\n");






// NUMBERS AS STRINGS
console.log("NUMBERS AS STRINGS");

const result1 = 3 + '30'; // 3 is converted to a string; result is string '330'
const result2 = 3 * '30'; // '30' is converted to a number; result is numeric 90

console.log(result1);
console.log(result2 );

console.log("\n\n");








//SYMBOLS
console.log("SYMBOLS");

const RED = Symbol();
const ORANGE = Symbol("The color of a sunset!");
console.log(RED === ORANGE); // false: every symbol is unique

console.log("\n\n");







// BOOLEANS
console.log("BOOLEANS");

const x = true ;
console.log(x);

console.log("\n\n");







// NULL AND UNDENED
console.log(" NULL AND UNDENED");

let currentTemp3;            // implicit value of undefined
console.log(currentTemp);   // output:-  undefined

const targetTemp = null;    // target Temp null -- "not yet known"
console.log(targetTemp);    // output:-  null

currentTemp3 = 19.5;        // currentTemp3 now has value
currentTemp3 = undefined;   // currentTemp3 appears as if it had never
                            // been initialized; not recommended
console.log(currentTemp3);  // output:-  undefined







































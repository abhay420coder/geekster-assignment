console.log("\n\n");
console.log("update the literals");



let c = 5;
let d = 6;
let add = c+d ;

console.log(c);
console.log(d);
console.log(add);

// update the literals 1st time
d = 72;
add= c+d;   // now add is also updated
console.log(`the update 1st time value of d is ${d}`);
console.log(`the update 1st time value of add is ${add}`);

// update the literals 2nd time
d = 22;
add= c+d;   // now add is also updated
console.log(`the update 2nd time value of d is ${d}`);
console.log(`the update 2nd time value of add is ${add}`);


// update the literals 3rd time
d = 37;
add= c+d;   // now add is also updated
console.log(`the update 3rd time value of d is ${d}`);
console.log(`the update 3rd time value of add is ${add}`);


// update the literals 4th time
d = 116;
add= c+d;   // now add is also updated
console.log(`the update 4th time value of d is ${d}`);
console.log(`the update 4th time value of add is ${add}`);


// update the literals 5th time
c = 142;
add= c+d;   // now add is also updated
console.log(`the update 1st time value of c is ${c}`);
console.log(`the update 5th time value of add is ${add}`);
--> literal is a container that contain any value.
--> we can change the value of literal at any time.
--> we declare literal with keyword "let"
--> for ex:-    let x = 20;   // here x is a literal that contains 20.
                let a = 25;   // here a is a literal that contains 25.
                let ramesh = 463;   // here ramesh is a literal that contains 463.
                let AsT = 212;   // here AsT is a literal that contains 212.
                let raj = 157;   // here raj is a literal that contains 157.
                let b2yhn = a+b;   // here b2yhn is a literal that contains a+b.


--> A literal is essentially a named value, and as the name implies, 
    the value can change at any time

--> For example, if we’re working on a climate control system, we might have
    a literal called currentTempC:

--> AASIGN THE literal:- 
                         let literalName = literalValue;

    When you declare a literal , you don’t have to provide it with an initial value.
    aap baad me bhi value de sakte ho.
                                            let literalName ;
                                                literalName = literalValue;

--> AASIGN THE MULTIPLE literal:-
                                    METHOD 1:- 
                                            let literalNAme3 = "value3" , literalNAme4 = "value4" , literalNAme5 = "value5" ;

                                    METHOD 2:-
                                            let literalNAme6 , literalNAme7 , literalNAme8  ;
                                                literalNAme6 = "value6" ;
                                                literalNAme7 = "value7" ;
                                                literalNAme8 = "value8" ;

                                    METHOD 2:-
                                            let literalNAme9 = "value9" , literalNAme10 , literalNAme11 , literalNAme12 = "value12" , literalNAme13 , literalNAme14 , literalNAme15 = "value15" , literalNAme16  ;
                                                literalNAme10 = "value10" ;
                                                literalNAme11 = "value11" ;
                                                literalNAme13 = "value13" ;
                                                literalNAme14 = "value14" ;
                                                literalNAme16 = "value16" ;

   

--> UPDATE THE literal :-
                            let literalName = value1;   // here "literalName" is a literal that contains "value1".
                                literalName = value2;   // now "literalName" is update and that contains "value2".

--> PRINT THE literal :-
                            console.log(literalName);
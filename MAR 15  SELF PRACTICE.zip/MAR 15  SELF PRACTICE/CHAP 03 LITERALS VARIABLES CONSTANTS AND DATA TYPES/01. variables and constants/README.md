    VARIABLES (var) AND CONSTANTS (const) AND LITERALS (let)

1. VARIABLES :-
        --> variable is a container that contain any value.
        --> we can change the value of variable at any time.
        --> we declare variable with keyword "var"
        --> for ex:-    var x = 20;   // here x is a variable that contains 20.
                        var a = 25;   // here a is a variable that contains 25.
                        var ramesh = 463;   // here ramesh is a variable that contains 463.
                        var AsT = 212;   // here AsT is a variable that contains 212.
                        var raj = 157;   // here raj is a variable that contains 157.
                        var b2yhn = a+b;   // here b2yhn is a variable that contains a+b.


        --> A variable is essentially a named value, and as the name implies, 
            the value can change at any time
        
        --> For example, if we’re working on a climate control system, we might have
            a variable called currentTempC:

        --> AASIGN THE VARIABLE:- 
                                 var variableName = variableValue;

            When you declare a variable , you don’t have to provide it with an initial value.
            aap baad me bhi value de sakte ho.
                                                    var variableName ;
                                                        variableName = variableValue;

        --> AASIGN THE MULTIPLE VARIABLE:-
                                            METHOD 1:- 
                                                    var variableNAme3 = "value3" , variableNAme4 = "value4" , variableNAme5 = "value5" ;

                                            METHOD 2:-
                                                    var variableNAme6 , variableNAme7 , variableNAme8  ;
                                                        variableNAme6 = "value6" ;
                                                        variableNAme7 = "value7" ;
                                                        variableNAme8 = "value8" ;

                                            METHOD 3:-
                                                    var variableNAme9 = "value9" , variableNAme10 , variableNAme11 , variableNAme12 = "value12" , variableNAme13 , variableNAme14 , variableNAme15 = "value15" , variableNAme16  ;
                                                        variableNAme10 = "value10" ;
                                                        variableNAme11 = "value11" ;
                                                        variableNAme13 = "value13" ;
                                                        variableNAme14 = "value14" ;
                                                        variableNAme16 = "value16" ;

           

        --> UPDATE THE VARIABLE :-
                                    var variableName = value1;   // here "variableName" is a variable that contains "value1".
                                        variableName = value2;   // now "variableName" is update and that contains "value2".

        --> PRINT THE VARIABLE :-
                                    console.log(variableName);   

        --> PRINT THE MULTIPLE VARIABLE :-

                                    // first method
                                    console.log(variableName1,variableName2,variableName3);

                                    // second method
                                    console.log(`${variableName1}  ${variableName2}  ${variableName3}`); 

                                    //  ydi $ ki super-power end krni hoto $ ke piche \ (forward-slash)  use krte hai



2. CONSONANT :- 
        --> consonant is a container that contain any value.
        --> we can not change/update the value of consonant at any time.
        --> we declare consonant with keyword "const"
        --> for ex:-    const x = 20;   // here x is a consonant that contains 20.
                        const a = 25;   // here a is a consonant that contains 25.
                        const ramesh = 463;   // here ramesh is a consonant that contains 463.
                        const AsT = 212;   // here AsT is a consonant that contains 212.
                        const raj = 157;   // here raj is a consonant that contains 157.
                        const b2yhn = a+b;   // here b2yhn is a consonant that contains a+b.

        
        --> AASIGN THE CONSONANT:- 
                                var consonantName = consonantValue;

            When you declare a consonant , you have to provide it with an initial value.


        --> AASIGN THE MULTIPLE CONSONANT:-
                                            METHOD 1:- 
                                                    var consonantNAme3 = "consonantValue3" , consonantNAme4 = "consonantValue4" , consonantNAme5 = "consonantValue5" ;

        --> PRINT THE CONSONANT :-
                                    console.log(consonantName); 

        --> PRINT THE MULTIPLE CONSONANT :-

                                    // first method
                                    console.log(consonantName1,consonantName2,consonantName3);

                                    // second method
                                    console.log(`${consonantName1}  ${consonantName2}  ${consonantName3}`); 

                                    //  ydi $ ki super-power end krni hoto $ ke piche \ (forward-slash)  use krte hai

        

3. LITERALS :-
                --> literal is a container that contain any value.
                --> we can change the value of literal at any time.
                --> we declare literal with keyword "let"
                --> for ex:-    let x = 20;   // here x is a literal that contains 20.
                                let a = 25;   // here a is a literal that contains 25.
                                let ramesh = 463;   // here ramesh is a literal that contains 463.
                                let AsT = 212;   // here AsT is a literal that contains 212.
                                let raj = 157;   // here raj is a literal that contains 157.
                                let b2yhn = a+b;   // here b2yhn is a literal that contains a+b.


                --> A literal is essentially a named value, and as the name implies, 
                    the value can change at any time

                --> For example, if we’re working on a climate control system, we might have
                    a literal called currentTempC:

                --> AASIGN THE LITERAL:- 
                                         let literalName = literalValue;

                    When you declare a literal , you don’t have to provide it with an initial value.
                    aap baad me bhi value de sakte ho.
                                                            let literalName ;
                                                                literalName = literalValue;

                --> AASIGN THE MULTIPLE LITERAL:-
                                                    METHOD 1:- 
                                                            let literalNAme3 = "value3" , literalNAme4 = "value4" , literalNAme5 = "value5" ;

                                                    METHOD 2:-
                                                            let literalNAme6 , literalNAme7 , literalNAme8  ;
                                                                literalNAme6 = "value6" ;
                                                                literalNAme7 = "value7" ;
                                                                literalNAme8 = "value8" ;

                                                    METHOD 3:-
                                                            let literalNAme9 = "value9" , literalNAme10 , literalNAme11 , literalNAme12 = "value12" , literalNAme13 , literalNAme14 , literalNAme15 = "value15" , literalNAme16  ;
                                                                literalNAme10 = "value10" ;
                                                                literalNAme11 = "value11" ;
                                                                literalNAme13 = "value13" ;
                                                                literalNAme14 = "value14" ;
                                                                literalNAme16 = "value16" ;

   

                --> UPDATE THE LITERAL :-
                                            let literalName = value1;   // here "literalName" is a literal that contains "value1".
                                                literalName = value2;   // now "literalName" is update and that contains "value2".

                --> PRINT THE LITERAL :-
                                            console.log(literalName);

                --> PRINT THE MULTIPLE LITERAL :-

                                    // first method
                                    console.log(literalName1,literalName2,literalName3);

                                    // second method
                                    console.log(`${literalName1}  ${literalName2}  ${literalName3}`); 

                                    //  ydi $ ki super-power end krni hoto $ ke piche \ (forward-slash)  use krte hai


                            


4. DIFFERENCE AMONG     "VARIABLES (var)" , "CONSTANTS (const)"   AND    "LITERALS (let)"

        VARIABLES (var) :-      1. Variable is a functional-scope.
                                2. We can update/change the value of variable.        
                                3. When you declare a variable , you don’t have to provide it with an initial value.  
                                4. Same Variable can be re-declare
                                5. Same Variable can be re-assign
                                6. Change the elements of constant array    
                                7. Change the properties of constant object

        CONSTANTS (const) :-    1. Consonant is a block-scope.
                                2. We can not update/change the value of consonant.  
                                3. When you declare a consonant , you have to provide it with an initial value.  
                                4. Same Consonant can not be re-declare.
                                5. Same Consonant can not be re-assign.
                                6. Change the elements of constant array    
                                7. Change the properties of constant object

        LITERALS (let) :-       1. Literals is a block-scope. 
                                2. We can update/change the value of literals.
                                3. When you declare a literal , you don’t have to provide it with an initial value.  
                                4. Same Literal can not be re-declare.
                                5. Same Literal can be re-assign.
                                6. Change the elements of constant array    
                                7. Change the properties of constant object





5. RE-DECLARE and RE-ASSIGN
        var  a;           // declare variable 
        a = 54;           // assign variable 
        console.log(a);
        var a ;           // re-declare variable first-time
        a =24 ;           // re-assign variable first-time
        console.log(a);
        var a ;           // re-declare variable second-time
        a =28 ;           // re-assign variable second-time
        console.log(a);




6. VARIABLES OR CONSTANTS OR LITERALS :-  Which to Use?

        1.  When we need to change/update the value of identifier,
            then we use/prefer     LITERALS (let).

        2.  When we don't need to change/update the value of identifier,
            then we use/prefer     CONSTANTS (const)

        3.  In general , you should prefer CONSTANTS(const) and LITERALS(let)  over VARIABLES(var).  








7. IDENTIER NAMES :- 
                        Variable and constant names are called identifiers, and they have naming rules:

                            • Identifiers must start with a letter, dollar sign ($), or underscore (_).
                            • Identifiers consist of letters, numbers, the dollar sign ($), and underscore (_).
                            • Unicode characters are allowed (for example, π or ö).
                            • Identifiers cannot be a reserved word


8. RESERVED WORD :- 
                    • await (reserved for future use)           • break                                 • case              
                    • class                                     • catch                                 • const         
                    • continue                                  • debugger                              • default                                   
                    • delete                                    • do                                    • else
                    • enum (reserved for future use)            • export                                • extends           
                    • false (literal value)                     • finally                               • for           
                    • function                                  • if                                    • implements (reserved for future use)      
                    • import                                    • in                                    • instanceof
                    • interface (reserved for future use)       • let                                   • new               
                    • null (literal value)                      • package (reserved for future use)     • private (reserved for future use)• protectd (reserved for future use)• public (reserved for future use)
                    • return                                    • super                                 • static (reserved for future use)
                    • switch                                    • this                                  • throw
                    • true (literal value)                      • try                                   • typeof
                    • var                                       • void                                  • while
                    • with                                      • yield



        The following words were reserved in ECMAScript specifications .
        They are no longer reserved words, but I discourage their use, as JavaScript implementations may
        (incorrectly) consider them reserved words:-

                    • abstract                                  • boolean                               • byte
                    • char                                      • double                                • final
                    • float                                     • goto                                  • int
                    • long                                      • native                                • short
                    • synchronized                              • transient                             • volatile














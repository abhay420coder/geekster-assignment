console.log('hello geeks');

console.log("\n\n");
console.log("ASSIGN THE VARIABLE");


// ASSIGN THE VARIABLE
var variableNAme1 = "value1" ;
console.log(variableNAme1);

// ASSIGN THE VARIABLE - 2nd method
var variableNAme2 ;
variableNAme2 = "value2" ;
console.log(variableNAme2);

// ASSIGN THE MULTIPLE VARIABLE
var variableNAme3 = "value3" , variableNAme4 = "value4" , variableNAme5 = "value5" ;
console.log(variableNAme3);
console.log(variableNAme4);
console.log(variableNAme5);

// ASSIGN THE MULTIPLE VARIABLE -2nd method
var variableNAme6 , variableNAme7 , variableNAme8  ;
variableNAme6 = "value6" ;
variableNAme7 = "value7" ;
variableNAme8 = "value8" ;
console.log(variableNAme6);
console.log(variableNAme7);
console.log(variableNAme8);

// ASSIGN THE MULTIPLE VARIABLE -3rd method
var variableNAme9 = "value9" , variableNAme10 , variableNAme11 , variableNAme12 = "value12" , variableNAme13 , variableNAme14 , variableNAme15 = "value15" , variableNAme16  ;
variableNAme10 = "value10" ;
variableNAme11 = "value11" ;
variableNAme13 = "value13" ;
variableNAme14 = "value14" ;
variableNAme16 = "value16" ;
console.log(variableNAme9);
console.log(variableNAme10);
console.log(variableNAme11);
console.log(variableNAme12);
console.log(variableNAme13);
console.log(variableNAme14);
console.log(variableNAme15);
console.log(variableNAme16);



console.log("\n\n");
console.log("update the variable");



var a = 5;
var b = 6;
var sum = a+b ;

console.log(a);
console.log(b);
console.log(sum);

// update the variable 1st time
b = 72;
sum= a+b;   // now sum is also updated
console.log(`the update 1st time value of b is ${b}`);
console.log(`the update 1st time value of sum is ${sum}`);

// update the variable 2nd time
b = 22;
sum= a+b;   // now sum is also updated
console.log(`the update 2nd time value of b is ${b}`);
console.log(`the update 2nd time value of sum is ${sum}`);


// update the variable 3rd time
b = 37;
sum= a+b;   // now sum is also updated
console.log(`the update 3rd time value of b is ${b}`);
console.log(`the update 3rd time value of sum is ${sum}`);


// update the variable 4th time
b = 116;
sum= a+b;   // now sum is also updated
console.log(`the update 4th time value of b is ${b}`);
console.log(`the update 4th time value of sum is ${sum}`);


// update the variable 5th time
a = 142;
sum= a+b;   // now sum is also updated
console.log(`the update 1st time value of a is ${a}`);
console.log(`the update 5th time value of sum is ${sum}`);















console.log("\n\n");
console.log("ASSIGN THE CONSONANT");



// ASSIGN THE CONSONANT
const constNAme1 = "constValue1" ;
console.log(constNAme1);

// WE CAN'T ASSIGN THE CONSONANT - 2nd method  --> 
// const constNAme2 ;
// constNAme2 = "constValue2" ;
// console.log(constNAme2);


// ASSIGN THE MULTIPLE CONSONANT
const constNAme3 = "constValue3" , constNAme4 = "constValue4" , constNAme5 = "constValue5" ;
console.log(constNAme3);
console.log(constNAme4);
console.log(constNAme5);















console.log("\n\n");
console.log("ASSIGN THE LITERALS");

// ASSIGN THE LITERALS
let letName1 = "letValue1" ;
console.log(letName1);

// ASSIGN THE LITERALS - 2nd method
let letName2 ;
letName2 = "letValue2" ;
console.log(letName2);

// ASSIGN THE MULTIPLE LITERALS
let letName3 = "letValue3" , letName4 = "letValue4" , letName5 = "letValue5" ;
console.log(letName3);
console.log(letName4);
console.log(letName5);

// ASSIGN THE MULTIPLE LITERALS -2nd method
let letName6 , letName7 , letName8  ;
letName6 = "letValue6" ;
letName7 = "letValue7" ;
letName8 = "letValue8" ;
console.log(letName6);
console.log(letName7);
console.log(letName8);

// ASSIGN THE MULTIPLE LITERALS -3rd method
let letName9 = "letValue9" , letName10 , letName11 , letName12 = "letValue12" , letName13 , letName14 , letName15 = "letValue15" , letName16  ;
letName10 = "letValue10" ;
letName11 = "letValue11" ;
letName13 = "letValue13" ;
letName14 = "letValue14" ;
letName16 = "letValue16" ;
console.log(letName9);
console.log(letName10);
console.log(letName11);
console.log(letName12);
console.log(letName13);
console.log(letName14);
console.log(letName15);
console.log(letName16);



console.log("\n\n");
console.log("update the literals");



let c = 5;
let d = 6;
let add = c+d ;

console.log(c);
console.log(d);
console.log(add);

// update the literals 1st time
d = 72;
add= c+d;   // now add is also updated
console.log(`the update 1st time value of d is ${d}`);
console.log(`the update 1st time value of add is ${add}`);

// update the literals 2nd time
d = 22;
add= c+d;   // now add is also updated
console.log(`the update 2nd time value of d is ${d}`);
console.log(`the update 2nd time value of add is ${add}`);


// update the literals 3rd time
d = 37;
add= c+d;   // now add is also updated
console.log(`the update 3rd time value of d is ${d}`);
console.log(`the update 3rd time value of add is ${add}`);


// update the literals 4th time
d = 116;
add= c+d;   // now add is also updated
console.log(`the update 4th time value of d is ${d}`);
console.log(`the update 4th time value of add is ${add}`);


// update the literals 5th time
c = 142;
add= c+d;   // now add is also updated
console.log(`the update 1st time value of c is ${c}`);
console.log(`the update 5th time value of add is ${add}`);





console.log("\n\n");
console.log("print more than one variable in single console");
var variableNew1 ;   // this is declaration of variable
var variableNew2 ;   // this is declaration of variable
var variableNew3 ;   // this is declaration of variable
variableNew1 = `abhay`;   // this is assign of variable
variableNew2 = 'kumar';   // this is assign of variable
variableNew3 = `singh`;   // this is assign of variable
// first method
console.log("first method :-   console.log(variableNew1,variableNew2,variableNew3);");

console.log(variableNew1,variableNew2,variableNew3);


// second method
console.log('seccond method :-   console.log(`${variableNew1}  ${variableNew2}  ${variableNew3}`); ')
console.log(`${variableNew1}  ${variableNew2}  ${variableNew3}`); 
//  ydi $ ki super-power end krni hoto $ ke piche \ (forward-slash)  use krte hai

1. OBJECTS 

1. DEFINITION :- 

         An object is a container, and the contents of that container can change over
        time (it’s the same object with different contents).



2. SYNTAX :-
                let objectName = {
                    "keyName" : keyvalue           // object me keyName ko doubleQuotes/singleQuotes/backTick ke andr likhna jaruri nhi hai
                }                                  // ydi nhi likhoge to javaSvript apke object ke keyName ko dtring hi consider krega

    SYNTAX:-

                let/var/const   objectName = {
                                                "key1" : value1 ,
                                                "key2" : value2 , 
                                                "key3" : value3 ,
                                                "key4" : value4 ,
                                                "key5" : value5 ,
                                                "key6" : value6 ,
                                                "key7" : value7 ,
                                                    .        .  ,
                                                    .        .  ,
                                                    .        .  ,
                                                    .        .  ,
                                                    .        .  ,
                                                    .        .  ,
                                                "keyN" : valueN ,
                                            };



3. CREATE AN OBJECT:-

        Let’s start with an empty object:
                                        ex:-        const obj = {};

        NOTE :- The contents of an object are called properties (or members), and 
                properties consist of a name (or key) and value. 
                
                We can say tha properties of object is key-value pair.

                Property names (or keys) must be strings or symbols, 
                and values can be any type (including other objects). 

                Objects can also contain functions.

4. ADD PROPERTY IN AN OBJECT 
                    
                        Let’s add a property color to obj:

                                    obj.size; // undefined
                                    obj.color; // "yellow"















5. CREATE An OBJECT

        1. -->    objectName = {}   :-   Creates a new object. 

                                    SYNTAX:-    objectName = {
                                                                "key1" : value1 
                                                                "key2" : value2 
                                                                "key3" : value3 
                                                                  .         .
                                                                  .         .
                                                                "keyN" : valueN 
                                                            }
                                    
                                    EXAMPLE:-
                                                const simpleObject1 = {
                                                                        key1 : "value1" ,  
                                                                        key2 : "value2" ,  
                                                                        key3 : "value3" ,  
                                                                    } ;

                                                console.log(simpleObject1);



        2. -->     Object()   :-   Creates a new object.

                            SYNTAX:-    objectName = new Object() ;
                                        objectName.key1 = "value1" ;
                                        objectName.key2 = "value2" ;
                                        objectName.key3 = "value3" ;
                                        objectName.key4 = "value4" ;
                                            .                .
                                            .                .
                                            .                .
                                        objectName.keyN = "valueN" ;

                            EXAMPLE:-
                                        const simpleObject1 = new Object() ;
                                        simpleObject1.key1 = "value1" ;
                                        simpleObject1.key2 = "value2" ;
                                        simpleObject1.key3 = "value3" ;
                                        simpleObject1.key4 = "value4" ;

                                        console.log(simpleObject1);  
                                        
                                                                  
                            SYNTAX:-    objectName = new Object(value) ; // If the value is null or undefined, 
                                                                         // it will create and return an empty object.

                            EXAMPLE:-
                                        let obj1 = new Object(undefined);
                                        console.log(obj1);   //output:-   {}

                                        let obj2 = new Object(undefined);
                                        console.log(obj2);   //output:-   {}



        3. -->     Object.create()   :-     Creates a new object with the specified prototype object and properties.

                                            Creates a new object, using an existing object 
                                            as the prototype of the newly created object.

                            SYNTAX:-    objectName = Object.create(proto)
                                        objectName   Object.create(proto, propertiesObject) 

                            EXAMPLE:-
                                        oco = Object.create( {} );      // create a normal object 
                                        oco.p = 1;                      // create a simple property on normal obj
                                        console.log(oco)                // {p: 1} -- Still seems normal

                                        oco2 = Object.create( [] );      // create a normal array 
                                        oco2.push(234)                   // create a simple property on normal array
                                        oco2.push(23)                   // create a simple property on normal array
                                        console.log(oco2)                // [2, 24] -- Still seems normal array


                            EXAMPLE:-
                                        let idx = { 
                                                    'name': "Aayush ", 
                                                    };

                                        let idxl = {
                                                    'name': "Geekster", 
                                                    };

                                        let obj = {};
                                            obj[idx] = "IDX"; 
                                            obj[idxl] = "IDX1"; 
                                            console.log(obj);           // OUTPUT:-  Object { [object Object]: "IDX1" }
















6. COPY/MERGE DATA OF An OBJECT

        1. -->    Object.assign()   :-  Copies the values of all enumerable own properties 
                                        from one or more source objects to a target object.

 

                                    SYNTAX:-    
                                            newObjectName =    Object.assign(target, ...sources)
                                            newObjectName =    Object.assign(targetObjectName, sourcesObjectName)
                                                            
                                    
                                    EXAMPLE:-
                                                const obj = { a: 1 };
                                                const copy = Object.assign({}, obj);
                                                console.log(copy);                          // { a: 1 }

                                    EXAMPLE:- (Merging two objects)
                                                const o1 = { a: 1 };
                                                const o2 = { b: 2 };
                                                const o3 = { c: 3 };

                                                const obj = Object.assign(o1, o2, o3);

                                                console.log(obj);                           // { a: 1, b: 2, c: 3 }
                                                console.log(o1);                            // { a: 1, b: 2, c: 3 }, target object itself is changed.

                                    EXAMPLE:- (Merging objects with same properties)
                                                const o4 = { a: 1, b: 1, c: 1 };
                                                const o5 = { b: 2, c: 2 };
                                                const o6 = { c: 3 };

                                                const obj2 = Object.assign({}, o1, o2, o3);
                                                console.log(obj2);                           // { a: 1, b: 2, c: 3 }                                       


      

                                                                  

    



7. MODIFY THE OBJECT 

        1. -->    Object.defineProperty() :-   defines a new property directly on an object, 
                                            or modifies an existing property on an object, 
                                            and returns the object.

                                                Adds the named property described by a given descriptor to an object.

                                    SYNTAX:-    
                                            Object.defineProperty(obj, property, descriptor)
                                    
                                    EXAMPLE:-
                                                const object1 = {};  
                                                Object.defineProperty(object1, 'property1', {  
                                                                                            value: 22, } );  

                                                object1.property1;  
                                                // throws an error in strict mode  
                                                console.log(object1.property1);             // output:- 22
                                    
                                    EXAMPLE:-
                                                const object1 = {};  
                                                Object.defineProperty(object1, 'property1', {  
                                                                                            value: 22,
                                                                                            value: 4,  
                                                                                            value: 4+13, } );  

                                                object1.property1;  
                                                // throws an error in strict mode  
                                                console.log(object1.property1);             // output:- 17
                                    
                                    EXAMPLE:-
                                                // using __proto__
                                                var obj = {};
                                                var descriptor = Object.create(null); // no inherited properties
                                                descriptor.value = 'static';

                                                // not enumerable, not configurable, not writable as defaults
                                                Object.defineProperty(obj, 'key', descriptor);

                                                // being explicit
                                                Object.defineProperty(obj, 'key', {
                                                  enumerable: false,
                                                  configurable: false,
                                                  writable: false,
                                                  value: 'static'
                                                });

                                                // recycling same object
                                                function withValue(value) {
                                                  var d = withValue.d || (
                                                    withValue.d = {
                                                      enumerable: false,
                                                      writable: false,
                                                      configurable: false,
                                                      value: value
                                                    }
                                                  );

                                                  // avoiding duplicate operation for assigning value
                                                  if (d.value !== value) d.value = value;

                                                  return d;
                                                }
                                                // ... and ...
                                                Object.defineProperty(obj, 'key', withValue('static'));

                                                // if freeze is available, prevents adding or
                                                // removing the object prototype properties
                                                // (value, get, set, enumerable, writable, configurable)
                                                (Object.freeze || Object)(Object.prototype);



        2. -->    Object.defineProperties() :-  defines new or modifies existing properties directly on an object, 
                                                returning the object.

                                                Adds the named properties described by a given descriptor to an object.

                                    SYNTAX:-    
                                            Object.defineProperties(obj, props)
                                    
                                    EXAMPLE:-
                                                var obj = {};
                                                Object.defineProperties(obj, {
                                                  'property1': {
                                                    value: true,
                                                    writable: true
                                                  },
                                                  'property2': {
                                                    value: 'Hello',
                                                    writable: false
                                                  }
                                                  // etc. etc.
                                                });
                                  











8. INSERT/ADD/PUSH A NEW key and value IN THE OBJECT 

        insert or add or push a new key-value in object  

                                    SYNTAX:-    
                                            objectName.keyName = keyValue ;
                          or                objectName["keyName"] = keyValue ;
                                             
                                    EXAMPLE:-
                                            const simpleObject1 = {} ;
                                            simpleObject1.key1 = "value1" ;
                                            simpleObject1.key2 = "value2" ;
                                            simpleObject1.key3 = "value3" ;
                                            simpleObject1.key4 = "value4" ;

                                            console.log(simpleObject1);           // output:-  Object { key1: "value1", key2: "value2", key3: "value3", key4: "value4" }                          
                                                                                         
                                    EXAMPLE:-
                                            const simpleObject2 = {} ;
                                            simpleObject2["key1"] = "value1" ;
                                            simpleObject2["key2"] = "value2" ;
                                            simpleObject2["key3"] = "value3" ;
                                            simpleObject2["key4"] = "value4" ;

                                            console.log(simpleObject2);           // output:-  Object { key1: "value1", key2: "value2", key3: "value3", key4: "value4" }                 










9. DELETE/REMOVE/POP DATA FROM An OBJECT

        delete or remove or pop a new key-value in objectt.

 

                                    SYNTAX:-    
                                            delete objectName.keyName
                                            delete objectName['kayName']



        delete or remove or pop a new property in objectt.

                                            delete objectName.property
                                            delete objectName['property']

                                                            
                                    
                                    EXAMPLE:-
                                            const simpleObject1 = {} ;
                                            simpleObject1.key1 = "value1" ;
                                            simpleObject1.key2 = "value2" ;
                                            simpleObject1.key3 = "value3" ;
                                            simpleObject1.key4 = "value4" ;

                                            console.log(simpleObject1);                         // output:-  Object { key1: "value1", key2: "value2", key3: "value3", key4: "value4" }                          
                        
                                            console.log(delete simpleObject1.key2);             // output:-  true                          
                                            console.log(simpleObject1);                         // output:-  Object { key1: "value1", key3: "value3", key4: "value4" }                          

                                            console.log(delete simpleObject1["key3"]);           // output:-  true
                                            console.log(simpleObject1);                         // output:-  Object { key1: "value1", key4: "value4" }                          

                                            



 




10. CONVERT An OBJECT to Array 

        1. -->    objectName = Object.entries()   :-    Returns an array containing all of the [key, value] pairs 
                                                            of a given object's own enumerable string properties. 

                                    SYNTAX:-    Object.entries(fromEntries)
                                    
                                    EXAMPLE:-
                                                const obj = { foo: 'bar', baz: 42 };
                                                console.log(Object.entries(obj)); // [ ['foo', 'bar'], ['baz', 42] ]

                                                // array like object
                                                const obj = { 0: 'a', 1: 'b', 2: 'c' };
                                                console.log(Object.entries(obj)); // [ ['0', 'a'], ['1', 'b'], ['2', 'c'] ]

                                                // array like object with random key ordering
                                                const anObj = { 100: 'a', 2: 'b', 7: 'c' };
                                                console.log(Object.entries(anObj)); // [ ['2', 'b'], ['7', 'c'], ['100', 'a'] ]

                                                // getFoo is property which isn't enumerable
                                                const myObj = Object.create({}, { getFoo: { value() { return this.foo; } } });
                                                myObj.foo = 'bar';
                                                console.log(Object.entries(myObj)); // [ ['foo', 'bar'] ]

                                                // non-object argument will be coerced to an object
                                                console.log(Object.entries('foo')); // [ ['0', 'f'], ['1', 'o'], ['2', 'o'] ]

                                                // returns an empty array for any primitive type except for strings (see the above example), since primitives have no own properties
                                                console.log(Object.entries(100)); // [ ]

                                                // iterate through key-value gracefully
                                                const obj = { a: 5, b: 7, c: 9 };
                                                for (const [key, value] of Object.entries(obj)) {
                                                  console.log(`${key} ${value}`); // "a 5", "b 7", "c 9"
                                                }

                                                // Or, using array extras
                                                Object.entries(obj).forEach(([key, value]) => {
                                                  console.log(`${key} ${value}`); // "a 5", "b 7", "c 9"
                                                });



        2. -->     arrayName = Object.keys()   :-     Returns an array containing all of the key 
                                                        of a given object's own enumerable string properties. 

                            SYNTAX:-    Object.keys(objectName)

                            EXAMPLE:-
                                        // simple array
                                        const arr = ['a', 'b', 'c'];
                                        console.log(Object.keys(arr)); // console: ['0', '1', '2']

                                        // array-like object
                                        const obj = { 0: 'a', 1: 'b', 2: 'c' };
                                        console.log(Object.keys(obj)); // console: ['0', '1', '2']

                                        // array-like object with random key ordering
                                        const anObj = { 100: 'a', 2: 'b', 7: 'c' };
                                        console.log(Object.keys(anObj)); // console: ['2', '7', '100']

                                        // getFoo is a property which isn't enumerable
                                        const myObj = Object.create({}, {
                                          getFoo: {
                                            value: function () { return this.foo; }
                                          }
                                        });
                                        myObj.foo = 1;
                                        console.log(Object.keys(myObj)); // console: ['foo']



        3. -->     arrayName = Object.values()   :-     Returns an array containing all of the value 
                                                        of a given object's own enumerable string properties. 

                            SYNTAX:-    Object.values(objectName)

                            EXAMPLE:-
                                        //simple array
                                        const obj = { foo: 'bar', baz: 42 };
                                        console.log(Object.values(obj)); // ['bar', 42]

                                        // Array-like object
                                        const arrayLikeObj1 = { 0: 'a', 1: 'b', 2: 'c' };
                                        console.log(Object.values(arrayLikeObj1 )); // ['a', 'b', 'c']

                                        // Array-like object with random key ordering
                                        // When using numeric keys, the values are returned in the keys' numerical order
                                        const arrayLikeObj2 = { 100: 'a', 2: 'b', 7: 'c' };
                                        console.log(Object.values(arrayLikeObj2 )); // ['b', 'c', 'a']

                                        // getFoo is property which isn't enumerable
                                        const my_obj = Object.create({}, { getFoo: { value: function() { return this.foo; } } });
                                        my_obj.foo = 'bar';
                                        console.log(Object.values(my_obj)); // ['bar']

                                        // non-object argument will be coerced to an object
                                        console.log(Object.values('foo')); // ['f', 'o', 'o']









11. CONVERT An Array to OBJECT

        1. -->    objectName = Object.fromEntries()   :-     Returns an array containing all of the [key, value] pairs 
                                                            of a given object's own enumerable string properties. 

                                    SYNTAX:-    Object.fromEntries(arrayName)
                                    
                                    EXAMPLE:-
                                                const entries = [ ['foo', 'bar'] , ['baz', 42] ];
                                                console.log(entries);                       // output:- Array [Array ["foo", "bar"], Array ["baz", 42]]
                                                
                                                const obj = Object.fromEntries(entries);
                                                console.log(obj);                           // output:- Object { foo: "bar", baz: 42 }

                                               




12. COMPARE TWO VALUES IN OBJECT 

        1. -->    Object.is()   :-      Compares if two values are the same value. 

                                        Equates all NaN values (which differs from both Abstract 
                                        Equality Comparison and Strict Equality Comparison).


                                    SYNTAX:-    Object.is(value1, value2);
                                    
                                    EXAMPLE:-
                                                // Case 1: Evaluation result is the same as using ===
                                                Object.is(25, 25);                // true
                                                Object.is('foo', 'foo');          // true
                                                Object.is('foo', 'bar');          // false
                                                Object.is(null, null);            // true
                                                Object.is(undefined, undefined);  // true
                                                Object.is(window, window);        // true
                                                Object.is([], []);                // false

                                                var foo = { a: 1 };
                                                var bar = { a: 1 };
                                                Object.is(foo, foo);              // true
                                                Object.is(foo, bar);              // false

                                                // Case 2: Signed zero
                                                Object.is(0, -0);                 // false
                                                Object.is(+0, -0);                // false
                                                Object.is(-0, -0);                // true
                                                Object.is(0n, -0n);               // true

                                                // Case 3: NaN
                                                Object.is(NaN, 0/0);              // true
                                                Object.is(NaN, Number.NaN)        // true











13. EXTENSION An OBJECT

        1. -->    Object.preventExtensions(objectName)   :- Prevents any extensions of an object.

                                                            prevents new properties from ever being added to an object 
                                                            (i.e. prevents future extensions to the object).

 

                                    SYNTAX:-    Object.preventExtensions(objectName)
                                    
                                    EXAMPLE:-
                                                // Object.preventExtensions returns the object
                                                // being made non-extensible.
                                                var obj = {};
                                                var obj2 = Object.preventExtensions(obj);
                                                obj === obj2; // true

                                                // Objects are extensible by default.
                                                var empty = {};
                                                Object.isExtensible(empty); // === true

                                                // ...but that can be changed.
                                                Object.preventExtensions(empty);
                                                Object.isExtensible(empty); // === false

                                                // Object.defineProperty throws when adding
                                                // a new property to a non-extensible object.
                                                var nonExtensible = { removable: true };
                                                Object.preventExtensions(nonExtensible);
                                                Object.defineProperty(nonExtensible, 'new', {
                                                  value: 8675309
                                                }); // throws a TypeError

                                                // In strict mode, attempting to add new properties
                                                // to a non-extensible object throws a TypeError.
                                                function fail() {
                                                  'use strict';
                                                  // throws a TypeError
                                                  nonExtensible.newProperty = 'FAIL';
                                                }
                                                fail();



        2. -->     Object.isExtensible(objectName)   :- determines if an object is extensible 
                                                        (whether it can have new properties added to it)

                            SYNTAX:-     Object.isExtensible(objectName)

                            EXAMPLE:-
                                        const object1 = {};

                                        console.log(Object.isExtensible(object1));
                                        // expected output: true

                                        Object.preventExtensions(object1);

                                        console.log(Object.isExtensible(object1));
                                        // expected output: false











14. FREEZES An OBJECT

        1. -->    Object.freeze(objectName)   :-    Prevents any extensions of an object.

                                                    freezes an object. 

                                                    A frozen object can no longer be changed; 
                                                    freezing an object prevents new properties from being added to it, 
                                                    existing properties from being removed, 
                                                    prevents changing the enumerability, configurability, 
                                                    or writability of existing properties, 
                                                    and prevents the values of existing properties 
                                                    from being changed. 
                                                    
                                                    In addition, freezing an object also prevents its prototype 
                                                    from being changed.

 

                                    SYNTAX:-    Object.freeze(objectName)
                                    
                                    EXAMPLE:-
                                                const obj = {
                                                  prop: 42
                                                };

                                                Object.freeze(obj);

                                                obj.prop = 33;
                                                // Throws an error in strict mode

                                                console.log(obj.prop);
                                                // expected output: 42



        2. -->    Object.isFrozen(objectName)   :- determines if an object is frozen.

                            SYNTAX:-     Object.isFrozen(objectName)

                            EXAMPLE:-
                                        const object1 = {
                                          property1: 42
                                        };

                                        console.log(Object.isFrozen(object1));
                                        // expected output: false

                                        Object.freeze(object1);

                                        console.log(Object.isFrozen(object1));
                                        // expected output: true
                                                                  











14. SEALS An OBJECT

        1. -->    Object.seal(objectName)   :-   seals an object, 
                                                preventing new properties from being added to it 
                                                and marking all existing properties as non-configurable. 
                                                
                                                Values of present properties can still be changed 
                                                as long as they are writable.

 

                                    SYNTAX:-    Object.seal(objectName)
                                    
                                    EXAMPLE:-
                                                const object1 = {
                                                  property1: 42
                                                };

                                                Object.seal(object1);
                                                object1.property1 = 33;
                                                console.log(object1.property1);
                                                // expected output: 33

                                                delete object1.property1; // cannot delete when sealed
                                                console.log(object1.property1);
                                                // expected output: 33



        2. -->    Object.isSealed(objectName)   :- determines if an object is sealed.

                            SYNTAX:-     Object.isSealed(objectName)

                            EXAMPLE:-
                                        const object1 = {
                                          property1: 42
                                        };

                                        console.log(Object.isSealed(object1));
                                        // expected output: false

                                        Object.seal(object1);

                                        console.log(Object.isSealed(object1));
                                        // expected output: true























Object.getOwnPropertyDescriptor()
Returns a property descriptor for a named property on an object.

Object.getOwnPropertyDescriptors()
Returns an object containing all own property descriptors for an object.

Object.getOwnPropertyNames()
Returns an array containing the names of all of the given object's own enumerable and non-enumerable properties.

Object.getOwnPropertySymbols()
Returns an array of all symbol properties found directly upon a given object.

Object.getPrototypeOf()
Returns the prototype (internal [[Prototype]] property) of the specified object.



Object.setPrototypeOf()
Sets the object's prototype (its internal [[Prototype]] property).



Instance properties
Object.prototype.constructor
Specifies the function that creates an object's prototype.

Object.prototype.__proto__
Points to the object which was used as prototype when the object was instantiated.

Instance methods
Object.prototype.__defineGetter__()
Associates a function with a property that, when accessed, executes that function and returns its return value.

Object.prototype.__defineSetter__()
Associates a function with a property that, when set, executes that function which modifies the property.

Object.prototype.__lookupGetter__()
Returns the function associated with the specified property by the __defineGetter__() method.

Object.prototype.__lookupSetter__()
Returns the function associated with the specified property by the __defineSetter__() method.

Object.prototype.hasOwnProperty()
Returns a boolean indicating whether an object contains the specified property as a direct property of that object and not inherited through the prototype chain.

Object.prototype.isPrototypeOf()
Returns a boolean indicating whether the object this method is called upon is in the prototype chain of the specified object.

Object.prototype.propertyIsEnumerable()
Returns a boolean indicating if the internal ECMAScript [[Enumerable]] attribute is set.

Object.prototype.toLocaleString()
Calls toString().

Object.prototype.toString()
Returns a string representation of the object.

Object.prototype.valueOf()
Returns the primitive value of the specified object.

// create simple object
console.log("create a simple object")

const simpleObject1 = {
    "key1" : "value1" ,  
    "key2" : "value2" ,  
    "key3" : "value3" ,  
    "key4" : "value4" ,  
    "key5" : "value5" , 
    "key6" : "value6" , 
    "key7" : "value7" , 
    "key8" : "value8" , 
    "key9" : "value9" , 
}

console.log(simpleObject1);

console.log("\n")

// ACCESS THE KEY (member) OF OBJECT -->    objectName.keyName
console.log("acces key of  simple object ----> objectName.keyName ")

const key1st = simpleObject1.key1
console.log(`the value of key1 is ${key1st} using simpleObject1.key1 `);

const key2nd = simpleObject1.key2
console.log(`the value of key2 is ${key2nd} using simpleObject1.key2 `);

const key3rd = simpleObject1.key3
console.log(`the value of key3 is ${key3rd} using simpleObject1.key3 `);

const key4th = simpleObject1.key4
console.log(`the value of key4 is ${key4th} using simpleObject1.key4 `);

const key5th = simpleObject1.key5
console.log(`the value of key5 is ${key5th} using simpleObject1.key5 `);

const key6th = simpleObject1.key6
console.log(`the value of key6 is ${key6th} using simpleObject1.key6 `);

const key7th = simpleObject1.key7
console.log(`the value of key7 is ${key7th} using simpleObject1.key7 `);

const key8th = simpleObject1.key8
console.log(`the value of key8 is ${key8th} using simpleObject1.key8 `);

const key9th = simpleObject1.key9
console.log(`the value of key9 is ${key9th} using simpleObject1.key9 `);

console.log("\n")


// ACCESS THE KEY (member) OF OBJECT -->   objectName["keyName"]
console.log(`acces key of  simple object ----> objectName["keyName"] `);

const key1a = simpleObject1["key1"];
console.log(`the value of key1 is ${key1a} using simpleObject1["key1"] `);

const key2a = simpleObject1["key2"];
console.log(`the value of key2 is ${key2a} using simpleObject1["key2"] `);

const key3a = simpleObject1["key3"];
console.log(`the value of key3 is ${key3a} using simpleObject1["key3"] `);

const key4a = simpleObject1["key4"];
console.log(`the value of key4 is ${key4a} using simpleObject1["key4"] `);

const key5a = simpleObject1["key5"];
console.log(`the value of key5 is ${key5a} using simpleObject1["key5"] `);

const key6a = simpleObject1["key6"];
console.log(`the value of key6 is ${key6a} using simpleObject1["key6"] `);

const key7a = simpleObject1["key7"];
console.log(`the value of key7 is ${key7a} using simpleObject1["key7"] `);

const key8a = simpleObject1["key8"];
console.log(`the value of key8 is ${key8a} using simpleObject1["key8"] `);

const key9a = simpleObject1["key9"];
console.log(`the value of key9 is ${key9a} using simpleObject1["key9"] `);





const keyList = Object.keys(simpleObject1);
console.log(keyList); //output:- ['key1', 'key2', 'key3', 'key4', 'key5', 'key6', 'key7', 'key8', 'key9']

const valueList = Object.values(simpleObject1);
console.log(valueList);  //output:-  ['value1', 'value2', 'value3', 'value4', 'value5', 'value6', 'value7', 'value8', 'value9']

const keyValueList = Object.entries(simpleObject1);
console.log(keyValueList);  //output:-  [['key1', 'value1'],['key2', 'value2'], ['key3', 'value3'],['key4', 'value4'],['key5', 'value5'],['key6', 'value6'],['key7', 'value7'],['key8', 'value8'],['key9', 'value9']]

const newObject = Object.fromEntries(keyValueList);
console.log(newObject);  //output:- {key1: 'value1', key2: 'value2', key3: 'value3', key4: 'value4', key5: 'value5', key6: 'value6', key7: 'value7', key8: 'value8', key9: 'value9'}








console.log("\n")
console.log("\n")
console.log("\n")
console.log("\n")


 // Case 1: Evaluation result is the same as using ===
 console.log(Object.is(25, 25));                // true
 console.log(Object.is('foo', 'foo'));          // true
 console.log(Object.is('foo', 'bar'));          // false
 console.log(Object.is(null, null));            // true
 console.log(Object.is(undefined, undefined));  // true
 console.log(Object.is(window, window));        // true
 console.log(Object.is([], []));                // false

 var foo = { a: 1 };
 var bar = { a: 1 };
 console.log(Object.is(foo, foo));              // true
 console.log(Object.is(foo, bar));              // false

 // Case 2: Signed zero
 console.log(Object.is(0, -0));                 // false
 console.log(Object.is(+0, -0));                // false
 console.log(Object.is(-0, -0));                // true
 console.log(Object.is(0n, -0n));               // true

 // Case 3: NaN
 console.log( Object.is(NaN, 0/0));              // true
 console.log(Object.is(NaN, Number.NaN));        // true
















































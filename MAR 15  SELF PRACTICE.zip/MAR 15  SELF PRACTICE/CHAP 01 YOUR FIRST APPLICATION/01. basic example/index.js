// this is single line comment

// this is 
// multi-line
// comment

/* this is a JavaScript comment......
        which  can spam multiple lines */







// now back in javaScript

console.time("your code took");

console.log("echo");     //   console.log( )       --> this is a method to print the output in console.



 /* * For this exercise, you’ll want to make sure the files you create are in the same directory or folder. 

    * I recommend that you create a new directory or folder for this example 
    * so it doesn’t get lost among your other files 
    
    * */

 console.log("echo1");  // you can write the string in double-quotes
 console.log('echo2');  // you can write the string in single-quote
 console.log(`echo3`);  // you can write the string in  back-quote  or back-tick. 

 console.log({index1:"value1" , 
                index2:"value2" ,
                index3:"value3" ,
                index4:"value4" ,
                index5:"value5" ,
                index6:"value6" ,
                index7:"value7" 
        });

 console.table({index1:"value1" , 
                index2:"value2" ,
                index3:"value3" ,
                index4:"value4" ,
                index5:"value5" ,
                index6:"value6" ,
                index7:"value7" 
        });
console.table('raj','raj2','raj3','raj4');

console.warn("this is a warning");

// console.clear();      // this will clear your console

console.timeEnd("your code took");


console.assert(56<15 , 'age>15 is not recommend');
console.error("this is an error");
 
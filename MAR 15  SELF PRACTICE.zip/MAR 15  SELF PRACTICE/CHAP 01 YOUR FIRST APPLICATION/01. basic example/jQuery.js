$(document).ready(function(){
    // 'use strict';
    console.log('jQuery.js is loaded');
})
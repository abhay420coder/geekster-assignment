1. Your First Application. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 
   Where to Start 
   The Tools 
   A Comment on Comments 
   Getting Started 
   The JavaScript Console 
   jQuery 
   Drawing Graphics Primitive 
   Automating Repetitive Tasks
   Handling User Input 
   Hello, World


1. comment in html
    --->                 <!-- this is an html comment
                                 which can span multiple lines -->
2. comment in css
    --->                /* this is a css comment......
                            which  can spam multiple lines */
3. comment in javaScript
    --->                // this is single line comment

                        // this is 
                        // multi-line
                        // comment

                        /* this is a JavaScript comment......
                            which  can spam 
                            multiple lines 
                        */


4. For this exercise, you’ll want to make sure the files you create are in
    the same directory or folder. 
    
    I recommend that you create a new directory or folder for this example 
    so it doesn’t get lost among your other files.

5. console.log( )       --> this is a method to print the output in console.

    console.log()       --> this is a method to print the output in general format in console.
    console.table({key1:value1 , key2:value2 , ..... })      --> this is a method to print key-value the output "key-value" in table format in console.
    console.warn()       --> this is a method to print the warning in console.
    console.clear();     --> this will clear your console

    console.time("identifierName");     --> from here console start to calculating your-code-time to run
    console.timeEnd("identifierName");     --> from here console end to calculating your-code-time to run

    console.assert(56<15 , 'age>15 is not recommend');  --> iska upyog condition check krne ke liye kiya jata hai ..... ki condition shi hai yaa nhi
    console.error(''this is an error');        --> this is a method to print the error in console. 





6.  you can write the string in double-quotes("") or single-quote('') or back-tick(``)
    ---->  but i will prefer in back-tick




7. if i want to add javaScript in html page 
        add script tag with src (source file) in  body
        ex:-    <script src="./index.js"></script>

8. if i want to add jQuery in html page 
        add script tag with src (host link)   in  head
        add script tag with src (source file) in  head
        ex:-  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  <!-- this is a way to link external jQuery host in your html page -->
              <script src="./jQuery.js"></script>     <!-- this is a way to link external js file for jQuery in your html page -->

              <!-- we can write code in jQuery.js -->
                $(document).ready( function() { /**write codehere */ } );  
                
                <!--OR ,  we can write code in jQuery.js -->
                $(document).ready( function() { 
                                                    /**write codehere */ 
                                                    
                                                } );            

                